/*    */ import java.awt.Color;
/*    */ import java.awt.Component;
/*    */ import javax.swing.JApplet;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Demo1
/*    */   extends JApplet
/*    */ {
/*    */   DemoUniverse du;
/*    */   
/*    */   public void init() {
/* 13 */     getContentPane().setLayout(null);
/* 14 */     setBackground(Color.white);
/* 15 */     this.du = new DemoUniverse();
/* 16 */     int w = (getSize()).width;
/* 17 */     int h = (getSize()).height;
/* 18 */     this.du.setSize(w - 300, w - 300);
/* 19 */     this.du.setLocation(0, 0);
/* 20 */     getContentPane().add((Component)this.du);
/* 21 */     ParameterPanel p = new ParameterPanel(this);
/* 22 */     p.setLocation(w - 300, 0);
/* 23 */     getContentPane().add(p);
/*    */   }
/*    */ }


/* Location:              C:\Users\Evgeniy\IdeaProjects\modern-lab-comp-applets\src\Lab_1\Cell & Properties\\\unitcell21.jar!\Demo1.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */