/*    */ import java.awt.Graphics;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class UpdateThread
/*    */   extends Thread
/*    */ {
/*    */   boolean stop;
/*    */   
/*    */   private UpdateThread(DemoUniverse this$0) {
/* 18 */     this.this$0 = this$0;
/*    */     
/* 20 */     this.stop = false;
/*    */   } private final DemoUniverse this$0;
/*    */   public void run() {
/* 23 */     while (!this.stop) {
/*    */       
/* 25 */       Graphics g = this.this$0.getGraphics();
/* 26 */       if (g != null) {
/*    */         
/* 28 */         this.this$0.paint(null);
/*    */         
/*    */         try {
/* 31 */           Thread.sleep(500L);
/*    */         }
/* 33 */         catch (InterruptedException interruptedException) {}
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   UpdateThread(DemoUniverse x$0, DemoUniverse.$1 x$1) {
/*    */     this(x$0);
/*    */   }
/*    */ }


/* Location:              C:\Users\Evgeniy\IdeaProjects\modern-lab-comp-applets\src\Lab_1\Cell & Properties\\\unitcell21.jar!\DemoUniverse$UpdateThread.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */