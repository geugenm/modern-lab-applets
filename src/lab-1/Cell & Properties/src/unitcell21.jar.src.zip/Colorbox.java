/*    */ import java.awt.Color;
/*    */ import java.awt.Cursor;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.event.MouseEvent;
/*    */ 
/*    */ public class Colorbox extends JComponent {
/*  7 */   private Color color = Color.red;
/*    */   
/*    */   public Colorbox() {
/* 10 */     addMouseListener(new MouseAdapter(this) {
/*    */           private final Colorbox this$0;
/*    */           
/*    */           public void mouseClicked(MouseEvent e) {
/* 14 */             Color c = JColorChooser.showDialog(this.this$0, "Choose a color", this.this$0.color);
/* 15 */             if (c != null) {
/*    */               
/* 17 */               this.this$0.color = c;
/* 18 */               this.this$0.repaint();
/*    */             } 
/*    */           }
/*    */           
/*    */           public void mouseEntered(MouseEvent e) {
/* 23 */             this.this$0.setCursor(new Cursor(12));
/*    */           }
/*    */           
/*    */           public void mouseExited(MouseEvent e) {
/* 27 */             this.this$0.setCursor(new Cursor(0));
/*    */           }
/*    */         });
/*    */   }
/*    */ 
/*    */   
/*    */   protected void paintComponent(Graphics g) {
/* 34 */     g.setColor(this.color);
/* 35 */     g.fillRect(0, 0, (getSize()).width, (getSize()).height);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setColor(Color c) {
/* 40 */     this.color = c;
/* 41 */     repaint();
/*    */   }
/*    */ 
/*    */   
/*    */   public Color getColor() {
/* 46 */     return this.color;
/*    */   }
/*    */ }


/* Location:              C:\Users\Evgeniy\IdeaProjects\modern-lab-comp-applets\src\Lab_1\Cell & Properties\\\unitcell21.jar!\Colorbox.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */