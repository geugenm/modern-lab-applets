/*    */ 
/*    */ 
/*    */ public class Logic
/*    */ {
/*  5 */   public static double scale = 0.1D;
/*  6 */   public static double scaleAtom = 0.01D;
/*  7 */   public static float planeAlpha = 0.6F;
/*    */ 
/*    */   
/*    */   public static boolean doubleLessEqual(double d1, double d2) {
/* 11 */     if (d1 <= d2)
/*    */     {
/* 13 */       return true;
/*    */     }
/* 15 */     if (Math.abs(d1 - d2) < 1.0E-6D)
/*    */     {
/* 17 */       return true;
/*    */     }
/*    */     
/* 20 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean doubleGreatEqual(double d1, double d2) {
/* 25 */     if (d1 >= d2)
/*    */     {
/* 27 */       return true;
/*    */     }
/* 29 */     if (Math.abs(d1 - d2) < 1.0E-6D)
/*    */     {
/* 31 */       return true;
/*    */     }
/* 33 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Evgeniy\IdeaProjects\modern-lab-comp-applets\src\Lab_1\Cell & Properties\\\unitcell21.jar!\Logic.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */