/*    */ package lattice;
/*    */ 
/*    */ import javax.vecmath.Vector3d;
/*    */ 
/*    */ public class FaceCenteredOrthorhombic
/*    */   extends Lattice
/*    */ {
/*    */   public FaceCenteredOrthorhombic(double a, double b, double c) {
/*  9 */     super(a, b, c, 90.0D, 90.0D, 90.0D);
/* 10 */     this.latticeName = "Face-Centered Orthorhombic";
/* 11 */     this.latticePoints = new Vector3d[4];
/*    */     
/* 13 */     this.latticePoints[0] = new Vector3d(0.0D, 0.0D, 0.0D);
/* 14 */     this.latticePoints[1] = new Vector3d(0.5D, 0.5D, 0.0D);
/* 15 */     this.latticePoints[2] = new Vector3d(0.5D, 0.0D, 0.5D);
/* 16 */     this.latticePoints[3] = new Vector3d(0.0D, 0.5D, 0.5D);
/*    */   }
/*    */ }


/* Location:              C:\Users\Evgeniy\IdeaProjects\modern-lab-comp-applets\src\Lab_1\Cell & Properties\\\unitcell21.jar!\lattice\FaceCenteredOrthorhombic.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */