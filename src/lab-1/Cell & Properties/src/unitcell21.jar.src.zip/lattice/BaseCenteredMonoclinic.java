/*    */ package lattice;
/*    */ 
/*    */ import javax.vecmath.Vector3d;
/*    */ 
/*    */ public class BaseCenteredMonoclinic
/*    */   extends Lattice
/*    */ {
/*    */   public BaseCenteredMonoclinic(double a, double b, double c, double beta) {
/*  9 */     super(a, b, c, 90.0D, beta, 90.0D);
/* 10 */     this.latticeName = "Base-Centered Monoclinic";
/* 11 */     this.latticePoints = new Vector3d[2];
/*    */     
/* 13 */     this.latticePoints[0] = new Vector3d(0.0D, 0.0D, 0.0D);
/* 14 */     this.latticePoints[1] = new Vector3d(0.5D, 0.5D, 0.0D);
/*    */   }
/*    */ }


/* Location:              C:\Users\Evgeniy\IdeaProjects\modern-lab-comp-applets\src\Lab_1\Cell & Properties\\\unitcell21.jar!\lattice\BaseCenteredMonoclinic.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */