/*    */ package lattice;
/*    */ 
/*    */ import javax.vecmath.Tuple3d;
/*    */ import javax.vecmath.Vector3d;
/*    */ 
/*    */ public class Lattice {
/*    */   private double a;
/*  8 */   protected String latticeName = "Lattice"; private double b; private double c; private double alpha;
/*    */   private double beta;
/*    */   
/*    */   public Lattice(double a, double b, double c, double alpha, double beta, double gamma) {
/* 12 */     this.a = a;
/* 13 */     this.b = b;
/* 14 */     this.c = c;
/* 15 */     this.alpha = alpha;
/* 16 */     this.beta = beta;
/* 17 */     this.gamma = gamma;
/* 18 */     this.latticePoints = new Vector3d[1];
/* 19 */     this.latticePoints[0] = new Vector3d(0.0D, 0.0D, 0.0D);
/*    */   }
/*    */   private double gamma;
/*    */   protected Vector3d[] latticePoints;
/*    */   
/*    */   public Vector3d coordinateConvert(Vector3d latticePoint) {
/* 25 */     Vector3d newPoint = new Vector3d(0.0D, 0.0D, 0.0D);
/* 26 */     double t1 = Math.cos(Math.toRadians(this.beta));
/* 27 */     double t2 = Math.cos(Math.toRadians(this.alpha));
/* 28 */     double t3 = 2 * t1 * t2 * Math.cos(Math.toRadians(this.gamma));
/* 29 */     t1 *= t1;
/* 30 */     t2 *= t2;
/* 31 */     double t4 = Math.sin(Math.toRadians(this.gamma));
/* 32 */     t4 *= t4;
/* 33 */     double t5 = Math.sqrt(true - (t1 + t2 - t3) / t4);
/*    */     
/* 35 */     double aa = ((Tuple3d)latticePoint).x * this.a;
/* 36 */     double bb = ((Tuple3d)latticePoint).y * this.b;
/* 37 */     double cc = ((Tuple3d)latticePoint).z * this.c;
/*    */     
/* 39 */     ((Tuple3d)newPoint).x = (float)(aa + bb * Math.cos(Math.toRadians(this.gamma)) + cc * Math.cos(Math.toRadians(this.beta)));
/* 40 */     ((Tuple3d)newPoint).y = (float)(bb * Math.sin(Math.toRadians(this.gamma)) + cc * Math.cos(Math.toRadians(this.alpha)));
/* 41 */     ((Tuple3d)newPoint).z = (float)(cc * t5);
/* 42 */     return newPoint;
/*    */   }
/*    */ 
/*    */   
/*    */   public Vector3d[] getLatticePoints() {
/* 47 */     return this.latticePoints;
/*    */   }
/*    */ 
/*    */   
/*    */   public double getA() {
/* 52 */     return this.a;
/*    */   }
/*    */   
/*    */   public double getB() {
/* 56 */     return this.b;
/*    */   }
/*    */   
/*    */   public double getC() {
/* 60 */     return this.c;
/*    */   }
/*    */   
/*    */   public double getAlpha() {
/* 64 */     return this.alpha;
/*    */   }
/*    */   
/*    */   public double getBeta() {
/* 68 */     return this.beta;
/*    */   }
/*    */   
/*    */   public double getGamma() {
/* 72 */     return this.gamma;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 76 */     return this.latticeName;
/*    */   }
/*    */ }


/* Location:              C:\Users\Evgeniy\IdeaProjects\modern-lab-comp-applets\src\Lab_1\Cell & Properties\\\unitcell21.jar!\lattice\Lattice.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */