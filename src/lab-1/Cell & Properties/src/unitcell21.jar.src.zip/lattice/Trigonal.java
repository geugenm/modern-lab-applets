/*   */ package lattice;
/*   */ 
/*   */ 
/*   */ public class Trigonal
/*   */   extends Lattice
/*   */ {
/*   */   public Trigonal(double a, double alpha) {
/* 8 */     super(a, a, a, alpha, alpha, alpha);
/* 9 */     this.latticeName = "Trigonal";
/*   */   }
/*   */ }


/* Location:              C:\Users\Evgeniy\IdeaProjects\modern-lab-comp-applets\src\Lab_1\Cell & Properties\\\unitcell21.jar!\lattice\Trigonal.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */