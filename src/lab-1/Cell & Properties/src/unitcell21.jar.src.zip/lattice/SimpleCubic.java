/*   */ package lattice;
/*   */ 
/*   */ 
/*   */ public class SimpleCubic
/*   */   extends Lattice
/*   */ {
/*   */   public SimpleCubic(double a) {
/* 8 */     super(a, a, a, 90.0D, 90.0D, 90.0D);
/* 9 */     this.latticeName = "Simple Cubic";
/*   */   }
/*   */ }


/* Location:              C:\Users\Evgeniy\IdeaProjects\modern-lab-comp-applets\src\Lab_1\Cell & Properties\\\unitcell21.jar!\lattice\SimpleCubic.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */