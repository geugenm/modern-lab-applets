/*   */ package lattice;
/*   */ 
/*   */ 
/*   */ public class SimpleOrthorhombic
/*   */   extends Lattice
/*   */ {
/*   */   public SimpleOrthorhombic(double a, double b, double c) {
/* 8 */     super(a, b, c, 90.0D, 90.0D, 90.0D);
/* 9 */     this.latticeName = "Simple Orthorhombic";
/*   */   }
/*   */ }


/* Location:              C:\Users\Evgeniy\IdeaProjects\modern-lab-comp-applets\src\Lab_1\Cell & Properties\\\unitcell21.jar!\lattice\SimpleOrthorhombic.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */