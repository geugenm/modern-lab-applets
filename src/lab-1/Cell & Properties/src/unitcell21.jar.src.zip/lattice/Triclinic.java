/*    */ package lattice;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Triclinic
/*    */   extends Lattice
/*    */ {
/*    */   public Triclinic(double a, double b, double c, double alpha, double beta, double gamma) {
/* 10 */     super(a, b, c, alpha, beta, gamma);
/* 11 */     this.latticeName = "Triclinic";
/*    */   }
/*    */ }


/* Location:              C:\Users\Evgeniy\IdeaProjects\modern-lab-comp-applets\src\Lab_1\Cell & Properties\\\unitcell21.jar!\lattice\Triclinic.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */