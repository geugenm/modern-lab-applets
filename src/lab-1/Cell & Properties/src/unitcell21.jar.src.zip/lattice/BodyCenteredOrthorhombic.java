/*    */ package lattice;
/*    */ 
/*    */ import javax.vecmath.Vector3d;
/*    */ 
/*    */ public class BodyCenteredOrthorhombic
/*    */   extends Lattice
/*    */ {
/*    */   public BodyCenteredOrthorhombic(double a, double b, double c) {
/*  9 */     super(a, b, c, 90.0D, 90.0D, 90.0D);
/* 10 */     this.latticeName = "Body-Centered Orthorhombic";
/* 11 */     this.latticePoints = new Vector3d[2];
/*    */     
/* 13 */     this.latticePoints[0] = new Vector3d(0.0D, 0.0D, 0.0D);
/* 14 */     this.latticePoints[1] = new Vector3d(0.5D, 0.5D, 0.5D);
/*    */   }
/*    */ }


/* Location:              C:\Users\Evgeniy\IdeaProjects\modern-lab-comp-applets\src\Lab_1\Cell & Properties\\\unitcell21.jar!\lattice\BodyCenteredOrthorhombic.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */