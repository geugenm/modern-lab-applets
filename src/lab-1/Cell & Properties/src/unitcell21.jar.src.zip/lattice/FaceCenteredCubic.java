/*    */ package lattice;
/*    */ 
/*    */ import javax.vecmath.Vector3d;
/*    */ 
/*    */ public class FaceCenteredCubic
/*    */   extends Lattice {
/*    */   public FaceCenteredCubic(double a) {
/*  8 */     super(a, a, a, 90.0D, 90.0D, 90.0D);
/*  9 */     this.latticeName = "Face-Centered Cubic";
/*    */     
/* 11 */     this.latticePoints = new Vector3d[4];
/*    */     
/* 13 */     this.latticePoints[0] = new Vector3d(0.0D, 0.0D, 0.0D);
/* 14 */     this.latticePoints[1] = new Vector3d(0.5D, 0.5D, 0.0D);
/* 15 */     this.latticePoints[2] = new Vector3d(0.5D, 0.0D, 0.5D);
/* 16 */     this.latticePoints[3] = new Vector3d(0.0D, 0.5D, 0.5D);
/*    */   }
/*    */ }


/* Location:              C:\Users\Evgeniy\IdeaProjects\modern-lab-comp-applets\src\Lab_1\Cell & Properties\\\unitcell21.jar!\lattice\FaceCenteredCubic.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */