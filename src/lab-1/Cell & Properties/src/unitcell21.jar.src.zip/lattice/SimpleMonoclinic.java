/*   */ package lattice;
/*   */ 
/*   */ 
/*   */ public class SimpleMonoclinic
/*   */   extends Lattice
/*   */ {
/*   */   public SimpleMonoclinic(double a, double b, double c, double beta) {
/* 8 */     super(a, b, c, 90.0D, beta, 90.0D);
/* 9 */     this.latticeName = "Simple Monoclinic";
/*   */   }
/*   */ }


/* Location:              C:\Users\Evgeniy\IdeaProjects\modern-lab-comp-applets\src\Lab_1\Cell & Properties\\\unitcell21.jar!\lattice\SimpleMonoclinic.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */