/*   */ package lattice;
/*   */ 
/*   */ 
/*   */ public class Hexagonal
/*   */   extends Lattice
/*   */ {
/*   */   public Hexagonal(double a, double c) {
/* 8 */     super(a, a, c, 90.0D, 90.0D, 120.0D);
/* 9 */     this.latticeName = "Hexagonal";
/*   */   }
/*   */ }


/* Location:              C:\Users\Evgeniy\IdeaProjects\modern-lab-comp-applets\src\Lab_1\Cell & Properties\\\unitcell21.jar!\lattice\Hexagonal.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */