/*    */ import java.awt.Font;
/*    */ import java.awt.Graphics;
/*    */ import javax.swing.JComponent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   extends JComponent
/*    */ {
/*    */   null(ParameterPanel this$0) {}
/*    */   
/*    */   public void paintComponent(Graphics g) {
/* 49 */     Font f = new Font("DialogInput", 0, 12);
/* 50 */     g.setFont(f);
/* 51 */     for (int i = 0; i < 3; i++)
/*    */     {
/* 53 */       g.drawOval(3, 2 + 25 * i, 3, 3);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\Evgeniy\IdeaProjects\modern-lab-comp-applets\src\Lab_1\Cell & Properties\\\unitcell21.jar!\ParameterPanel$2.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */