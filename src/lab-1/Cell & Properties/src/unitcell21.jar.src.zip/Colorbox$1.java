/*    */ import java.awt.Color;
/*    */ import java.awt.Cursor;
/*    */ import java.awt.event.MouseAdapter;
/*    */ import java.awt.event.MouseEvent;
/*    */ import javax.swing.JColorChooser;
/*    */ 
/*    */ class null
/*    */   extends MouseAdapter {
/*    */   null(Colorbox this$0) {
/* 10 */     this.this$0 = this$0;
/*    */   }
/*    */   private final Colorbox this$0;
/*    */   public void mouseClicked(MouseEvent e) {
/* 14 */     Color c = JColorChooser.showDialog(this.this$0, "Choose a color", Colorbox.access$0(this.this$0));
/* 15 */     if (c != null) {
/*    */       
/* 17 */       Colorbox.access$1(this.this$0, c);
/* 18 */       this.this$0.repaint();
/*    */     } 
/*    */   }
/*    */   
/*    */   public void mouseEntered(MouseEvent e) {
/* 23 */     this.this$0.setCursor(new Cursor(12));
/*    */   }
/*    */   
/*    */   public void mouseExited(MouseEvent e) {
/* 27 */     this.this$0.setCursor(new Cursor(0));
/*    */   }
/*    */ }


/* Location:              C:\Users\Evgeniy\IdeaProjects\modern-lab-comp-applets\src\Lab_1\Cell & Properties\\\unitcell21.jar!\Colorbox$1.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */