/*      */ import java.awt.Color;
/*      */ import java.awt.Font;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.ItemEvent;
/*      */ import java.awt.event.ItemListener;
/*      */ import java.awt.event.MouseEvent;
/*      */ import javax.media.j3d.Transform3D;
/*      */ import javax.swing.JCheckBox;
/*      */ import javax.swing.JLabel;
/*      */ 
/*      */ public class ParameterPanel extends JPanel {
/*   13 */   private JLabel jLabel1 = new JLabel();
/*   14 */   private JComboBox latticeSelect = new JComboBox();
/*   15 */   private JLabel gridLabel = new JLabel();
/*   16 */   private JSlider gridSlider = new JSlider();
/*   17 */   private JCheckBox showGrid = new JCheckBox();
/*   18 */   private JCheckBox showUnitGrid = new JCheckBox();
/*   19 */   private JButton resetButton = new JButton();
/*   20 */   private JLabel jLabel2 = new JLabel();
/*   21 */   private JLabel jLabel3 = new JLabel();
/*   22 */   private JLabel jLabel4 = new JLabel();
/*   23 */   private JLabel jLabel5 = new JLabel();
/*   24 */   private JLabel jLabel6 = new JLabel();
/*   25 */   private JLabel jLabel7 = new JLabel();
/*   26 */   private JLabel jLabel8 = new JLabel();
/*   27 */   private JTextField aField = new JTextField();
/*   28 */   private JTextField bField = new JTextField();
/*   29 */   private JTextField cField = new JTextField();
/*      */   
/*   31 */   private JComponent unit1 = new JComponent(this)
/*      */     {
/*      */       protected void paintComponent(Graphics g)
/*      */       {
/*   35 */         Font f = new Font("DialogInput", 0, 12);
/*   36 */         g.setFont(f);
/*   37 */         for (int i = 0; i < 3; i++) {
/*      */           
/*   39 */           g.drawString("A", 2, 16 + 25 * i);
/*   40 */           g.drawOval(3, 2 + 25 * i, 3, 3);
/*      */         } 
/*      */       }
/*      */     };
/*      */   
/*   45 */   private JComponent unit2 = new JComponent(this)
/*      */     {
/*      */       public void paintComponent(Graphics g)
/*      */       {
/*   49 */         Font f = new Font("DialogInput", 0, 12);
/*   50 */         g.setFont(f);
/*   51 */         for (int i = 0; i < 3; i++)
/*      */         {
/*   53 */           g.drawOval(3, 2 + 25 * i, 3, 3); } 
/*      */       }
/*      */     };
/*      */   
/*   57 */   private JTextField alphaField = new JTextField();
/*   58 */   private JTextField betaField = new JTextField();
/*   59 */   private JTextField gammaField = new JTextField();
/*   60 */   private JLabel jLabel9 = new JLabel();
/*   61 */   private JComboBox atomSize = new JComboBox();
/*   62 */   private JComboBox attachAtomsList = new JComboBox();
/*   63 */   private JButton setParameter = new JButton();
/*   64 */   private Colorbox atomColor = new Colorbox();
/*   65 */   private JLabel jLabel10 = new JLabel();
/*   66 */   private JLabel jLabel11 = new JLabel();
/*   67 */   private JLabel jLabel12 = new JLabel();
/*   68 */   private JTextField aShiftField = new JTextField();
/*   69 */   private JTextField bShiftField = new JTextField();
/*   70 */   private JTextField cShiftField = new JTextField();
/*   71 */   private JButton removeButton = new JButton();
/*   72 */   private JButton addButton = new JButton();
/*   73 */   private JLabel jLabel13 = new JLabel();
/*   74 */   private JCheckBox h_sign = new JCheckBox();
/*   75 */   private JCheckBox k_sign = new JCheckBox();
/*   76 */   private JCheckBox l_sign = new JCheckBox();
/*   77 */   private JLabel jLabel14 = new JLabel();
/*   78 */   private JLabel hLabel = new JLabel();
/*   79 */   private JLabel kLabel = new JLabel();
/*   80 */   private JLabel lLabel = new JLabel();
/*   81 */   private JLabel jLabel16 = new JLabel();
/*   82 */   private JLabel jLabel17 = new JLabel();
/*   83 */   private JLabel jLabel18 = new JLabel();
/*   84 */   private JCheckBox showPlane = new JCheckBox();
/*   85 */   private JCheckBox showDirection = new JCheckBox();
/*   86 */   private JCheckBox showPoints = new JCheckBox();
/*   87 */   private JLabel jLabel19 = new JLabel();
/*   88 */   private JComboBox customLib = new JComboBox();
/*   89 */   private JButton saveButton = new JButton();
/*   90 */   private JComboBox preDefineLib = new JComboBox();
/*   91 */   private JLabel jLabel110 = new JLabel();
/*      */   
/*      */   private Object demo;
/*      */   
/*   95 */   private Vector preLibList = new Vector(); Vector customLibList; private JCheckBox perspective; private JButton jButton1; private JButton jButton2; private JCheckBox blackOption; private JLabel jLabel15; private JLabel jLabel111; private JLabel jLabel112;
/*      */   class CrystalInfo { String name; String lattice;
/*      */     String a;
/*      */     String b;
/*      */     String c;
/*      */     String alpha;
/*      */     String beta;
/*      */     String gamma;
/*  103 */     Vector atoms = new Vector(5);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     CrystalInfo(ParameterPanel this$0) {} }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setup() {
/*      */     Trigonal trigonal;
/*  260 */     double a = Double.parseDouble(this.aField.getText());
/*  261 */     double b = Double.parseDouble(this.bField.getText());
/*  262 */     double c = Double.parseDouble(this.cField.getText());
/*  263 */     double alpha = Double.parseDouble(this.alphaField.getText());
/*  264 */     double beta = Double.parseDouble(this.betaField.getText());
/*  265 */     double gamma = Double.parseDouble(this.gammaField.getText());
/*      */     
/*  267 */     Lattice lattice = null;
/*  268 */     if (this.latticeSelect.getSelectedItem().equals("Simple Cubic")) {
/*      */       
/*  270 */       SimpleCubic simpleCubic = new SimpleCubic(a);
/*      */       
/*  272 */       this.bField.setText(String.valueOf(a));
/*  273 */       this.cField.setText(String.valueOf(a));
/*  274 */       this.alphaField.setText("90.0");
/*  275 */       this.betaField.setText("90.0");
/*  276 */       this.gammaField.setText("90.0");
/*      */       
/*  278 */       this.aField.setEnabled(true);
/*  279 */       this.bField.setEnabled(false);
/*  280 */       this.cField.setEnabled(false);
/*  281 */       this.alphaField.setEnabled(false);
/*  282 */       this.betaField.setEnabled(false);
/*  283 */       this.gammaField.setEnabled(false);
/*      */     }
/*  285 */     else if (this.latticeSelect.getSelectedItem().equals("Face-Centered Cubic")) {
/*      */ 
/*      */       
/*  288 */       FaceCenteredCubic faceCenteredCubic = new FaceCenteredCubic(a);
/*      */       
/*  290 */       this.bField.setText(String.valueOf(a));
/*  291 */       this.cField.setText(String.valueOf(a));
/*  292 */       this.alphaField.setText("90.0");
/*  293 */       this.betaField.setText("90.0");
/*  294 */       this.gammaField.setText("90.0");
/*      */       
/*  296 */       this.aField.setEnabled(true);
/*  297 */       this.bField.setEnabled(false);
/*  298 */       this.cField.setEnabled(false);
/*  299 */       this.alphaField.setEnabled(false);
/*  300 */       this.betaField.setEnabled(false);
/*  301 */       this.gammaField.setEnabled(false);
/*      */     }
/*  303 */     else if (this.latticeSelect.getSelectedItem().equals("Body-Centered Cubic")) {
/*      */ 
/*      */       
/*  306 */       BodyCenteredCubic bodyCenteredCubic = new BodyCenteredCubic(a);
/*      */       
/*  308 */       this.bField.setText(String.valueOf(a));
/*  309 */       this.cField.setText(String.valueOf(a));
/*  310 */       this.alphaField.setText("90.0");
/*  311 */       this.betaField.setText("90.0");
/*  312 */       this.gammaField.setText("90.0");
/*      */       
/*  314 */       this.aField.setEnabled(true);
/*  315 */       this.bField.setEnabled(false);
/*  316 */       this.cField.setEnabled(false);
/*  317 */       this.alphaField.setEnabled(false);
/*  318 */       this.betaField.setEnabled(false);
/*  319 */       this.gammaField.setEnabled(false);
/*      */     }
/*  321 */     else if (this.latticeSelect.getSelectedItem().equals("Hexagonal")) {
/*      */       
/*  323 */       Hexagonal hexagonal = new Hexagonal(a, c);
/*      */       
/*  325 */       this.bField.setText(String.valueOf(a));
/*  326 */       this.alphaField.setText("90.0");
/*  327 */       this.betaField.setText("90.0");
/*  328 */       this.gammaField.setText("120.0");
/*      */       
/*  330 */       this.aField.setEnabled(true);
/*  331 */       this.bField.setEnabled(false);
/*  332 */       this.cField.setEnabled(true);
/*  333 */       this.alphaField.setEnabled(false);
/*  334 */       this.betaField.setEnabled(false);
/*  335 */       this.gammaField.setEnabled(false);
/*      */     }
/*  337 */     else if (this.latticeSelect.getSelectedItem().equals("Simple Monoclinic")) {
/*      */ 
/*      */       
/*  340 */       SimpleMonoclinic simpleMonoclinic = new SimpleMonoclinic(a, b, c, beta);
/*      */       
/*  342 */       this.alphaField.setText("90.0");
/*  343 */       this.gammaField.setText("90.0");
/*      */       
/*  345 */       this.aField.setEnabled(true);
/*  346 */       this.bField.setEnabled(true);
/*  347 */       this.cField.setEnabled(true);
/*  348 */       this.alphaField.setEnabled(false);
/*  349 */       this.betaField.setEnabled(true);
/*  350 */       this.gammaField.setEnabled(false);
/*      */     }
/*  352 */     else if (this.latticeSelect.getSelectedItem().equals("Base-Centered Monoclinic")) {
/*      */ 
/*      */       
/*  355 */       BaseCenteredMonoclinic baseCenteredMonoclinic = new BaseCenteredMonoclinic(a, b, c, beta);
/*      */       
/*  357 */       this.alphaField.setText("90.0");
/*  358 */       this.gammaField.setText("90.0");
/*      */       
/*  360 */       this.aField.setEnabled(true);
/*  361 */       this.bField.setEnabled(true);
/*  362 */       this.cField.setEnabled(true);
/*  363 */       this.alphaField.setEnabled(false);
/*  364 */       this.betaField.setEnabled(true);
/*  365 */       this.gammaField.setEnabled(false);
/*      */     }
/*  367 */     else if (this.latticeSelect.getSelectedItem().equals("Simple Orthorhombic")) {
/*      */ 
/*      */       
/*  370 */       SimpleOrthorhombic simpleOrthorhombic = new SimpleOrthorhombic(a, b, c);
/*      */       
/*  372 */       this.alphaField.setText("90.0");
/*  373 */       this.betaField.setText("90.0");
/*  374 */       this.gammaField.setText("90.0");
/*      */       
/*  376 */       this.aField.setEnabled(true);
/*  377 */       this.bField.setEnabled(true);
/*  378 */       this.cField.setEnabled(true);
/*  379 */       this.alphaField.setEnabled(false);
/*  380 */       this.betaField.setEnabled(false);
/*  381 */       this.gammaField.setEnabled(false);
/*      */     }
/*  383 */     else if (this.latticeSelect.getSelectedItem().equals("Base-Centered Orthorhombic")) {
/*      */ 
/*      */       
/*  386 */       BaseCenteredOrthorhombic baseCenteredOrthorhombic = new BaseCenteredOrthorhombic(a, b, c);
/*      */       
/*  388 */       this.alphaField.setText("90.0");
/*  389 */       this.betaField.setText("90.0");
/*  390 */       this.gammaField.setText("90.0");
/*      */       
/*  392 */       this.aField.setEnabled(true);
/*  393 */       this.bField.setEnabled(true);
/*  394 */       this.cField.setEnabled(true);
/*  395 */       this.alphaField.setEnabled(false);
/*  396 */       this.betaField.setEnabled(false);
/*  397 */       this.gammaField.setEnabled(false);
/*      */     }
/*  399 */     else if (this.latticeSelect.getSelectedItem().equals("Body-Centered Orthorhombic")) {
/*      */ 
/*      */       
/*  402 */       BodyCenteredOrthorhombic bodyCenteredOrthorhombic = new BodyCenteredOrthorhombic(a, b, c);
/*      */       
/*  404 */       this.alphaField.setText("90.0");
/*  405 */       this.betaField.setText("90.0");
/*  406 */       this.gammaField.setText("90.0");
/*      */       
/*  408 */       this.aField.setEnabled(true);
/*  409 */       this.bField.setEnabled(true);
/*  410 */       this.cField.setEnabled(true);
/*  411 */       this.alphaField.setEnabled(false);
/*  412 */       this.betaField.setEnabled(false);
/*  413 */       this.gammaField.setEnabled(false);
/*      */     }
/*  415 */     else if (this.latticeSelect.getSelectedItem().equals("Face-Centered Orthorhombic")) {
/*      */ 
/*      */       
/*  418 */       FaceCenteredOrthorhombic faceCenteredOrthorhombic = new FaceCenteredOrthorhombic(a, b, c);
/*      */       
/*  420 */       this.alphaField.setText("90.0");
/*  421 */       this.betaField.setText("90.0");
/*  422 */       this.gammaField.setText("90.0");
/*      */       
/*  424 */       this.aField.setEnabled(true);
/*  425 */       this.bField.setEnabled(true);
/*  426 */       this.cField.setEnabled(true);
/*  427 */       this.alphaField.setEnabled(false);
/*  428 */       this.betaField.setEnabled(false);
/*  429 */       this.gammaField.setEnabled(false);
/*      */     }
/*  431 */     else if (this.latticeSelect.getSelectedItem().equals("Simple Tetragonal")) {
/*      */ 
/*      */       
/*  434 */       SimpleTetragonal simpleTetragonal = new SimpleTetragonal(a, c);
/*      */       
/*  436 */       this.bField.setText(String.valueOf(a));
/*  437 */       this.alphaField.setText("90.0");
/*  438 */       this.betaField.setText("90.0");
/*  439 */       this.gammaField.setText("90.0");
/*      */       
/*  441 */       this.aField.setEnabled(true);
/*  442 */       this.bField.setEnabled(false);
/*  443 */       this.cField.setEnabled(true);
/*  444 */       this.alphaField.setEnabled(false);
/*  445 */       this.betaField.setEnabled(false);
/*  446 */       this.gammaField.setEnabled(false);
/*      */     }
/*  448 */     else if (this.latticeSelect.getSelectedItem().equals("Body-Centered Tetragonal")) {
/*      */ 
/*      */       
/*  451 */       BodyCenteredTetragonal bodyCenteredTetragonal = new BodyCenteredTetragonal(a, c);
/*      */       
/*  453 */       this.bField.setText(String.valueOf(a));
/*  454 */       this.alphaField.setText("90.0");
/*  455 */       this.betaField.setText("90.0");
/*  456 */       this.gammaField.setText("90.0");
/*      */       
/*  458 */       this.aField.setEnabled(true);
/*  459 */       this.bField.setEnabled(false);
/*  460 */       this.cField.setEnabled(true);
/*  461 */       this.alphaField.setEnabled(false);
/*  462 */       this.betaField.setEnabled(false);
/*  463 */       this.gammaField.setEnabled(false);
/*      */     }
/*  465 */     else if (this.latticeSelect.getSelectedItem().equals("Triclinic")) {
/*      */       
/*  467 */       Triclinic triclinic = new Triclinic(a, b, c, alpha, beta, gamma);
/*      */       
/*  469 */       this.aField.setEnabled(true);
/*  470 */       this.bField.setEnabled(true);
/*  471 */       this.cField.setEnabled(true);
/*  472 */       this.alphaField.setEnabled(true);
/*  473 */       this.betaField.setEnabled(true);
/*  474 */       this.gammaField.setEnabled(true);
/*      */     }
/*  476 */     else if (this.latticeSelect.getSelectedItem().equals("Trigonal")) {
/*      */       
/*  478 */       trigonal = new Trigonal(a, alpha);
/*      */       
/*  480 */       this.bField.setText(String.valueOf(a));
/*  481 */       this.cField.setText(String.valueOf(a));
/*  482 */       this.betaField.setText(String.valueOf(alpha));
/*  483 */       this.gammaField.setText(String.valueOf(alpha));
/*      */       
/*  485 */       this.aField.setEnabled(true);
/*  486 */       this.bField.setEnabled(false);
/*  487 */       this.cField.setEnabled(false);
/*  488 */       this.alphaField.setEnabled(true);
/*  489 */       this.betaField.setEnabled(false);
/*  490 */       this.gammaField.setEnabled(false);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  496 */     int gridNum = this.gridSlider.getValue();
/*  497 */     this.gridLabel.setText("Grid=".concat(String.valueOf(String.valueOf(gridNum))));
/*      */     
/*  499 */     AtomInfo[] atomInfos = new AtomInfo[this.attachAtomsList.getItemCount()];
/*  500 */     Vector3d[] atomShifts = new Vector3d[this.attachAtomsList.getItemCount()];
/*      */     
/*  502 */     for (int i = 0; i < this.attachAtomsList.getItemCount(); i++) {
/*      */       
/*  504 */       String str = this.attachAtomsList.getItemAt(i);
/*  505 */       StringTokenizer st = new StringTokenizer(str, ",");
/*  506 */       double ashift = Double.parseDouble(st.nextToken().trim());
/*  507 */       double bshift = Double.parseDouble(st.nextToken().trim());
/*  508 */       double cshift = Double.parseDouble(st.nextToken().trim());
/*  509 */       atomShifts[i] = new Vector3d(ashift, bshift, cshift);
/*  510 */       int size = Integer.parseInt(st.nextToken().trim());
/*  511 */       String colorStr = st.nextToken().trim();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  521 */       int color = Integer.parseInt(colorStr, 16);
/*  522 */       atomInfos[i] = new AtomInfo(size * Logic.scaleAtom, new Color(color));
/*      */     } 
/*  524 */     int h = (this.h_sign.isSelected() ? -1 : 1) * Integer.parseInt(this.hLabel.getText());
/*      */     
/*  526 */     int k = (this.k_sign.isSelected() ? -1 : 1) * Integer.parseInt(this.kLabel.getText());
/*      */     
/*  528 */     int l = (this.l_sign.isSelected() ? -1 : 1) * Integer.parseInt(this.lLabel.getText());
/*      */ 
/*      */     
/*  531 */     Crystal crystal = new Crystal((Lattice)trigonal, gridNum, atomInfos, atomShifts, (Demo1)this.demo);
/*      */     
/*  533 */     if (this.showPoints.isSelected()) {
/*      */       
/*  535 */       crystal.addLatticePointBranch();
/*      */     }
/*      */     else {
/*      */       
/*  539 */       crystal.removeLatticePointBranch();
/*      */     } 
/*  541 */     if (this.showDirection.isSelected()) {
/*      */       
/*  543 */       crystal.addDirectionBranch(h, k, l);
/*      */     }
/*      */     else {
/*      */       
/*  547 */       crystal.removeDirectionBranch();
/*      */     } 
/*  549 */     if (this.showPlane.isSelected()) {
/*      */       
/*  551 */       crystal.addPlaneBranch(h, k, l);
/*      */     }
/*      */     else {
/*      */       
/*  555 */       crystal.removePlaneBranch();
/*      */     } 
/*  557 */     if (this.showGrid.isSelected()) {
/*      */       
/*  559 */       crystal.addGridBranch();
/*      */     }
/*      */     else {
/*      */       
/*  563 */       crystal.removeGridBranch();
/*      */     } 
/*  565 */     if (this.showUnitGrid.isSelected()) {
/*      */       
/*  567 */       crystal.addSingleCellBranch();
/*      */     }
/*      */     else {
/*      */       
/*  571 */       crystal.removeSingleCellBranch();
/*      */     } 
/*  573 */     Demo1 demo = (Demo1)this.demo;
/*  574 */     demo.du.setRootObject(crystal);
/*  575 */     System.gc();
/*      */   }
/*      */ 
/*      */   
/*      */   void jbInit() throws Exception {
/*  580 */     this.jLabel1.setFont(new Font("DialogInput", 0, 12));
/*  581 */     this.jLabel1.setForeground(Color.red);
/*  582 */     this.jLabel1.setText("14 Bravais Lattices");
/*  583 */     this.jLabel1.setBounds(new Rectangle(5, 24, 161, 18));
/*  584 */     setLayout(null);
/*  585 */     setBackground(Color.white);
/*  586 */     setFont(new Font("DialogInput", 0, 12));
/*  587 */     setBorder(BorderFactory.createEtchedBorder());
/*  588 */     setSize(300, 400);
/*  589 */     this.latticeSelect.setFont(new Font("DialogInput", 0, 12));
/*  590 */     this.latticeSelect.setForeground(Color.red);
/*  591 */     this.latticeSelect.setBounds(new Rectangle(5, 45, 260, 22));
/*  592 */     this.latticeSelect.addItemListener(new ItemListener(this) {
/*      */           private final ParameterPanel this$0;
/*      */           
/*      */           public void itemStateChanged(ItemEvent e) {
/*  596 */             this.this$0.latticeSelect_itemStateChanged(e);
/*      */           }
/*      */         });
/*  599 */     this.gridLabel.setFont(new Font("DialogInput", 0, 12));
/*  600 */     this.gridLabel.setText("Grid=2");
/*  601 */     this.gridLabel.setBounds(new Rectangle(5, 75, 52, 24));
/*  602 */     this.gridSlider.setMaximum(5);
/*  603 */     this.gridSlider.setMinimum(1);
/*  604 */     this.gridSlider.setValue(2);
/*  605 */     this.gridSlider.setBackground(Color.white);
/*  606 */     this.gridSlider.setBounds(new Rectangle(53, 75, 82, 24));
/*  607 */     this.gridSlider.addChangeListener(new ChangeListener(this) {
/*      */           private final ParameterPanel this$0;
/*      */           
/*      */           public void stateChanged(ChangeEvent e) {
/*  611 */             this.this$0.gridSlider_stateChanged(e);
/*      */           }
/*      */         });
/*  614 */     this.showGrid.setBackground(Color.white);
/*  615 */     this.showGrid.setSelected(true);
/*  616 */     this.showGrid.setBounds(new Rectangle(134, 75, 26, 24));
/*  617 */     this.showUnitGrid.setBackground(Color.white);
/*  618 */     this.showUnitGrid.setSelected(true);
/*  619 */     this.showUnitGrid.setBounds(new Rectangle(159, 75, 26, 24));
/*  620 */     this.resetButton.setBounds(new Rectangle(183, 75, 51, 20));
/*  621 */     this.resetButton.setFont(new Font("DialogInput", 0, 12));
/*  622 */     this.resetButton.setMargin(new Insets(0, 0, 0, 0));
/*  623 */     this.resetButton.setText("reset");
/*  624 */     this.resetButton.addActionListener(new ActionListener(this) {
/*      */           private final ParameterPanel this$0;
/*      */           
/*      */           public void actionPerformed(ActionEvent e) {
/*  628 */             this.this$0.resetButton_actionPerformed(e);
/*      */           }
/*      */         });
/*  631 */     this.jLabel2.setFont(new Font("DialogInput", 0, 12));
/*  632 */     this.jLabel2.setForeground(Color.blue);
/*  633 */     this.jLabel2.setText("Lattice Parameter");
/*  634 */     this.jLabel2.setBounds(new Rectangle(5, 110, 127, 20));
/*  635 */     this.jLabel3.setBackground(Color.white);
/*  636 */     this.jLabel3.setFont(new Font("DialogInput", 0, 12));
/*  637 */     this.jLabel3.setForeground(Color.blue);
/*  638 */     this.jLabel3.setText("a =");
/*  639 */     this.jLabel3.setBounds(new Rectangle(5, 135, 27, 20));
/*  640 */     this.jLabel4.setBounds(new Rectangle(5, 185, 27, 20));
/*  641 */     this.jLabel4.setBackground(Color.white);
/*  642 */     this.jLabel4.setFont(new Font("DialogInput", 0, 12));
/*  643 */     this.jLabel4.setForeground(Color.blue);
/*  644 */     this.jLabel4.setText("c =");
/*  645 */     this.jLabel5.setBounds(new Rectangle(144, 135, 55, 20));
/*  646 */     this.jLabel5.setFont(new Font("DialogInput", 0, 12));
/*  647 */     this.jLabel5.setForeground(Color.blue);
/*  648 */     this.jLabel5.setText("alpha =");
/*  649 */     this.jLabel6.setBounds(new Rectangle(5, 160, 27, 20));
/*  650 */     this.jLabel6.setBackground(Color.white);
/*  651 */     this.jLabel6.setFont(new Font("DialogInput", 0, 12));
/*  652 */     this.jLabel6.setForeground(Color.blue);
/*  653 */     this.jLabel6.setText("b =");
/*  654 */     this.jLabel7.setBounds(new Rectangle(144, 185, 55, 20));
/*  655 */     this.jLabel7.setFont(new Font("DialogInput", 0, 12));
/*  656 */     this.jLabel7.setForeground(Color.blue);
/*  657 */     this.jLabel7.setText("gamma =");
/*  658 */     this.jLabel8.setBounds(new Rectangle(144, 160, 55, 20));
/*  659 */     this.jLabel8.setFont(new Font("DialogInput", 0, 12));
/*  660 */     this.jLabel8.setForeground(Color.blue);
/*  661 */     this.jLabel8.setText("beta  =");
/*  662 */     this.aField.setFont(new Font("DialogInput", 0, 12));
/*  663 */     this.aField.setForeground(Color.blue);
/*  664 */     this.aField.setText("4.0");
/*  665 */     this.aField.setBounds(new Rectangle(40, 135, 63, 20));
/*  666 */     this.bField.setFont(new Font("DialogInput", 0, 12));
/*  667 */     this.bField.setForeground(Color.blue);
/*  668 */     this.bField.setText("4.0");
/*  669 */     this.bField.setBounds(new Rectangle(40, 160, 63, 20));
/*  670 */     this.cField.setFont(new Font("DialogInput", 0, 12));
/*  671 */     this.cField.setForeground(Color.blue);
/*  672 */     this.cField.setText("4.0");
/*  673 */     this.cField.setBounds(new Rectangle(40, 185, 63, 20));
/*  674 */     this.alphaField.setBounds(new Rectangle(203, 135, 63, 20));
/*  675 */     this.alphaField.setText("4.0");
/*  676 */     this.alphaField.setFont(new Font("DialogInput", 0, 12));
/*  677 */     this.alphaField.setForeground(Color.blue);
/*  678 */     this.betaField.setBounds(new Rectangle(203, 160, 63, 20));
/*  679 */     this.betaField.setText("4.0");
/*  680 */     this.betaField.setFont(new Font("DialogInput", 0, 12));
/*  681 */     this.betaField.setForeground(Color.blue);
/*  682 */     this.gammaField.setBounds(new Rectangle(203, 185, 63, 20));
/*  683 */     this.gammaField.setText("4.0");
/*  684 */     this.gammaField.setFont(new Font("DialogInput", 0, 12));
/*  685 */     this.gammaField.setForeground(Color.blue);
/*  686 */     this.jLabel9.setFont(new Font("DialogInput", 0, 12));
/*  687 */     this.jLabel9.setForeground(Color.magenta);
/*  688 */     this.jLabel9.setText("Basis Atoms");
/*  689 */     this.jLabel9.setBounds(new Rectangle(5, 225, 90, 20));
/*  690 */     this.atomSize.setFont(new Font("DialogInput", 0, 12));
/*  691 */     this.atomSize.setForeground(Color.magenta);
/*  692 */     this.atomSize.setBounds(new Rectangle(178, 250, 47, 20));
/*  693 */     this.attachAtomsList.setFont(new Font("DialogInput", 0, 12));
/*  694 */     this.attachAtomsList.setForeground(Color.magenta);
/*  695 */     this.attachAtomsList.setBounds(new Rectangle(97, 225, 200, 20));
/*  696 */     this.setParameter.setBounds(new Rectangle(135, 110, 35, 20));
/*  697 */     this.setParameter.setFont(new Font("DialogInput", 0, 12));
/*  698 */     this.setParameter.setForeground(Color.blue);
/*  699 */     this.setParameter.setMargin(new Insets(0, 0, 0, 0));
/*  700 */     this.setParameter.setText("set");
/*  701 */     this.setParameter.addMouseListener(new MouseAdapter(this) {
/*      */           private final ParameterPanel this$0;
/*      */           
/*      */           public void mouseClicked(MouseEvent e) {
/*  705 */             this.this$0.setParameter_mouseClicked(e);
/*      */           }
/*      */         });
/*  708 */     this.atomColor.setBounds(new Rectangle(91, 250, 20, 20));
/*  709 */     this.jLabel10.setFont(new Font("DialogInput", 0, 12));
/*  710 */     this.jLabel10.setForeground(Color.magenta);
/*  711 */     this.jLabel10.setText("Atom Color=");
/*  712 */     this.jLabel10.setBounds(new Rectangle(5, 250, 80, 20));
/*  713 */     this.jLabel11.setFont(new Font("DialogInput", 0, 12));
/*  714 */     this.jLabel11.setForeground(Color.magenta);
/*  715 */     this.jLabel11.setText("Size =");
/*  716 */     this.jLabel11.setBounds(new Rectangle(127, 250, 50, 20));
/*  717 */     this.jLabel12.setFont(new Font("DialogInput", 0, 12));
/*  718 */     this.jLabel12.setForeground(Color.magenta);
/*  719 */     this.jLabel12.setText("xyz:");
/*  720 */     this.jLabel12.setBounds(new Rectangle(5, 275, 31, 20));
/*  721 */     this.aShiftField.setFont(new Font("DialogInput", 0, 12));
/*  722 */     this.aShiftField.setText("0.0");
/*  723 */     this.aShiftField.setBounds(new Rectangle(39, 275, 46, 20));
/*  724 */     this.bShiftField.setFont(new Font("DialogInput", 0, 12));
/*  725 */     this.bShiftField.setText("0.0");
/*  726 */     this.bShiftField.setBounds(new Rectangle(110, 275, 46, 20));
/*  727 */     this.cShiftField.setFont(new Font("DialogInput", 0, 12));
/*  728 */     this.cShiftField.setText("0.0");
/*  729 */     this.cShiftField.setBounds(new Rectangle(183, 275, 46, 20));
/*  730 */     this.removeButton.setBounds(new Rectangle(248, 250, 46, 20));
/*  731 */     this.removeButton.setFont(new Font("DialogInput", 0, 12));
/*  732 */     this.removeButton.setForeground(Color.magenta);
/*  733 */     this.removeButton.setMargin(new Insets(0, 0, 0, 0));
/*  734 */     this.removeButton.setText("rmv");
/*  735 */     this.removeButton.addActionListener(new ActionListener(this) {
/*      */           private final ParameterPanel this$0;
/*      */           
/*      */           public void actionPerformed(ActionEvent e) {
/*  739 */             this.this$0.removeButton_actionPerformed(e);
/*      */           }
/*      */         });
/*  742 */     this.addButton.setText("add");
/*  743 */     this.addButton.addActionListener(new ActionListener(this) {
/*      */           private final ParameterPanel this$0;
/*      */           
/*      */           public void actionPerformed(ActionEvent e) {
/*  747 */             this.this$0.addButton_actionPerformed(e);
/*      */           }
/*      */         });
/*  750 */     this.addButton.setMargin(new Insets(0, 0, 0, 0));
/*  751 */     this.addButton.setForeground(Color.magenta);
/*  752 */     this.addButton.setFont(new Font("DialogInput", 0, 12));
/*  753 */     this.addButton.setBounds(new Rectangle(248, 275, 46, 20));
/*  754 */     this.jLabel13.setBackground(Color.white);
/*  755 */     this.jLabel13.setFont(new Font("DialogInput", 0, 12));
/*  756 */     this.jLabel13.setText("neg. sign");
/*  757 */     this.jLabel13.setBounds(new Rectangle(5, 300, 68, 20));
/*  758 */     this.h_sign.setBackground(Color.white);
/*  759 */     this.h_sign.setFont(new Font("DialogInput", 0, 12));
/*  760 */     this.h_sign.setMargin(new Insets(0, 0, 0, 0));
/*  761 */     this.h_sign.setText("-");
/*  762 */     this.h_sign.setBounds(new Rectangle(141, 300, 35, 20));
/*  763 */     this.h_sign.addItemListener(new ItemListener(this) {
/*      */           private final ParameterPanel this$0;
/*      */           
/*      */           public void itemStateChanged(ItemEvent e) {
/*  767 */             this.this$0.h_sign_itemStateChanged(e);
/*      */           }
/*      */         });
/*  770 */     this.k_sign.setBounds(new Rectangle(181, 300, 35, 20));
/*  771 */     this.k_sign.addItemListener(new ItemListener(this) {
/*      */           private final ParameterPanel this$0;
/*      */           
/*      */           public void itemStateChanged(ItemEvent e) {
/*  775 */             this.this$0.k_sign_itemStateChanged(e);
/*      */           }
/*      */         });
/*  778 */     this.k_sign.setText("-");
/*  779 */     this.k_sign.setFont(new Font("DialogInput", 0, 12));
/*  780 */     this.k_sign.setMargin(new Insets(0, 0, 0, 0));
/*  781 */     this.k_sign.setBackground(Color.white);
/*  782 */     this.l_sign.setBounds(new Rectangle(221, 300, 35, 20));
/*  783 */     this.l_sign.addItemListener(new ItemListener(this) {
/*      */           private final ParameterPanel this$0;
/*      */           
/*      */           public void itemStateChanged(ItemEvent e) {
/*  787 */             this.this$0.l_sign_itemStateChanged(e);
/*      */           }
/*      */         });
/*  790 */     this.l_sign.setText("-");
/*  791 */     this.l_sign.setFont(new Font("DialogInput", 0, 12));
/*  792 */     this.l_sign.setMargin(new Insets(0, 0, 0, 0));
/*  793 */     this.l_sign.setBackground(Color.white);
/*  794 */     this.jLabel14.setFont(new Font("DialogInput", 0, 12));
/*  795 */     this.jLabel14.setText("Miller Indices");
/*  796 */     this.jLabel14.setBounds(new Rectangle(5, 320, 101, 20));
/*  797 */     this.hLabel.setFont(new Font("DialogInput", 0, 12));
/*  798 */     this.hLabel.setText("1");
/*  799 */     this.hLabel.setBounds(new Rectangle(158, 320, 15, 18));
/*  800 */     this.kLabel.setBounds(new Rectangle(198, 320, 15, 18));
/*  801 */     this.kLabel.setText("0");
/*  802 */     this.kLabel.setFont(new Font("DialogInput", 0, 12));
/*  803 */     this.lLabel.setBounds(new Rectangle(238, 320, 15, 18));
/*  804 */     this.lLabel.setText("0");
/*  805 */     this.lLabel.setFont(new Font("DialogInput", 0, 12));
/*  806 */     this.jLabel16.setBounds(new Rectangle(142, 345, 66, 20));
/*  807 */     this.jLabel16.setText("Direction");
/*  808 */     this.jLabel16.setFont(new Font("DialogInput", 0, 12));
/*  809 */     this.jLabel17.setBounds(new Rectangle(229, 345, 48, 20));
/*  810 */     this.jLabel17.setText("Points");
/*  811 */     this.jLabel17.setFont(new Font("DialogInput", 0, 12));
/*  812 */     this.jLabel18.setFont(new Font("DialogInput", 0, 12));
/*  813 */     this.jLabel18.setText("Plane");
/*  814 */     this.jLabel18.setBounds(new Rectangle(78, 345, 37, 20));
/*  815 */     this.showPlane.setBackground(Color.white);
/*  816 */     this.showPlane.setBounds(new Rectangle(120, 345, 18, 20));
/*  817 */     this.showDirection.setBackground(Color.white);
/*  818 */     this.showDirection.setFont(new Font("DialogInput", 0, 12));
/*  819 */     this.showDirection.setBounds(new Rectangle(210, 345, 18, 20));
/*  820 */     this.showPoints.setBounds(new Rectangle(279, 345, 18, 20));
/*  821 */     this.showPoints.setFont(new Font("DialogInput", 0, 12));
/*  822 */     this.showPoints.setSelected(true);
/*  823 */     this.showPoints.setBackground(Color.white);
/*  824 */     this.jLabel19.setBounds(new Rectangle(5, 345, 65, 20));
/*  825 */     this.jLabel19.setFont(new Font("DialogInput", 0, 12));
/*  826 */     this.jLabel19.setText("SHOW");
/*  827 */     this.customLib.setFont(new Font("DialogInput", 0, 12));
/*  828 */     this.customLib.setBounds(new Rectangle(5, 370, 54, 20));
/*  829 */     this.customLib.addItemListener(new ItemListener(this) {
/*      */           private final ParameterPanel this$0;
/*      */           
/*      */           public void itemStateChanged(ItemEvent e) {
/*  833 */             this.this$0.customLib_itemStateChanged(e);
/*      */           }
/*      */         });
/*  836 */     this.saveButton.setBounds(new Rectangle(69, 370, 46, 20));
/*  837 */     this.saveButton.setFont(new Font("DialogInput", 0, 12));
/*  838 */     this.saveButton.setMargin(new Insets(0, 0, 0, 0));
/*  839 */     this.saveButton.setText("Save");
/*  840 */     this.saveButton.addActionListener(new ActionListener(this) {
/*      */           private final ParameterPanel this$0;
/*      */           
/*      */           public void actionPerformed(ActionEvent e) {
/*  844 */             this.this$0.saveButton_actionPerformed(e);
/*      */           }
/*      */         });
/*  847 */     this.preDefineLib.setFont(new Font("DialogInput", 0, 12));
/*  848 */     this.preDefineLib.setBounds(new Rectangle(176, 370, 115, 20));
/*  849 */     this.preDefineLib.addItemListener(new ItemListener(this) {
/*      */           private final ParameterPanel this$0;
/*      */           
/*      */           public void itemStateChanged(ItemEvent e) {
/*  853 */             this.this$0.preDefineLib_itemStateChanged(e);
/*      */           }
/*      */         });
/*  856 */     this.jLabel110.setFont(new Font("DialogInput", 0, 12));
/*  857 */     this.jLabel110.setText("Lib");
/*  858 */     this.jLabel110.setBounds(new Rectangle(145, 370, 26, 20));
/*  859 */     this.unit1.setFont(new Font("DialogInput", 0, 12));
/*  860 */     this.unit2.setFont(new Font("DialogInput", 0, 12));
/*  861 */     this.perspective.setBackground(Color.white);
/*  862 */     this.perspective.setFont(new Font("DialogInput", 0, 12));
/*  863 */     this.perspective.setForeground(Color.green);
/*  864 */     this.perspective.setText("perspective");
/*  865 */     this.perspective.setBounds(new Rectangle(182, 3, 110, 23));
/*  866 */     this.perspective.addItemListener(new ItemListener(this) {
/*      */           private final ParameterPanel this$0;
/*      */           
/*      */           public void itemStateChanged(ItemEvent e) {
/*  870 */             this.this$0.perspective_itemStateChanged(e);
/*      */           }
/*      */         });
/*  873 */     this.jButton1.setBackground(Color.lightGray);
/*  874 */     this.jButton1.setBounds(new Rectangle(-3, 68, 310, 4));
/*  875 */     this.jButton1.setMinimumSize(new Dimension(0, 0));
/*  876 */     this.jButton1.setPreferredSize(new Dimension(0, 0));
/*  877 */     this.jButton1.setMargin(new Insets(0, 0, 0, 0));
/*  878 */     this.jButton2.setMargin(new Insets(0, 0, 0, 0));
/*  879 */     this.jButton2.setPreferredSize(new Dimension(0, 0));
/*  880 */     this.jButton2.setMinimumSize(new Dimension(0, 0));
/*  881 */     this.jButton2.setBounds(new Rectangle(-1, 213, 310, 4));
/*  882 */     this.jButton2.setBackground(Color.lightGray);
/*  883 */     this.blackOption.addItemListener(new ItemListener(this) {
/*      */           private final ParameterPanel this$0;
/*      */           
/*      */           public void itemStateChanged(ItemEvent e) {
/*  887 */             this.this$0.blackOption_itemStateChanged(e);
/*      */           }
/*      */         });
/*  890 */     this.blackOption.setBounds(new Rectangle(6, 3, 151, 23));
/*  891 */     this.blackOption.setText("black background");
/*  892 */     this.blackOption.setForeground(Color.green);
/*  893 */     this.blackOption.setSelected(true);
/*  894 */     this.blackOption.setFont(new Font("DialogInput", 0, 12));
/*  895 */     this.blackOption.setBackground(Color.white);
/*  896 */     this.jLabel15.setBounds(new Rectangle(86, 275, 11, 20));
/*  897 */     this.jLabel15.setText("a");
/*  898 */     this.jLabel15.setForeground(Color.magenta);
/*  899 */     this.jLabel15.setFont(new Font("SansSerif", 1, 14));
/*  900 */     this.jLabel111.setFont(new Font("SansSerif", 1, 14));
/*  901 */     this.jLabel111.setForeground(Color.magenta);
/*  902 */     this.jLabel111.setText("b");
/*  903 */     this.jLabel111.setBounds(new Rectangle(158, 275, 12, 20));
/*  904 */     this.jLabel112.setBounds(new Rectangle(231, 275, 12, 20));
/*  905 */     this.jLabel112.setText("c");
/*  906 */     this.jLabel112.setForeground(Color.magenta);
/*  907 */     this.jLabel112.setFont(new Font("SansSerif", 1, 14));
/*  908 */     add(this.gridLabel, (Object)null);
/*      */     
/*  910 */     this.unit1.setBounds(new Rectangle(109, 132, 15, 75));
/*  911 */     this.unit2.setBounds(new Rectangle(272, 132, 15, 75));
/*  912 */     add(this.jLabel9, (Object)null);
/*  913 */     add(this.alphaField, (Object)null);
/*  914 */     add(this.jLabel7, (Object)null);
/*  915 */     add(this.aField, (Object)null);
/*  916 */     add(this.jLabel8, (Object)null);
/*  917 */     add(this.cField, (Object)null);
/*  918 */     add(this.jLabel4, (Object)null);
/*  919 */     add(this.unit1, (Object)null);
/*  920 */     add(this.jLabel5, (Object)null);
/*  921 */     add(this.jLabel2, (Object)null);
/*  922 */     add(this.unit2, (Object)null);
/*  923 */     add(this.gammaField, (Object)null);
/*  924 */     add(this.jLabel3, (Object)null);
/*  925 */     add(this.betaField, (Object)null);
/*  926 */     add(this.bField, (Object)null);
/*  927 */     add(this.jLabel6, (Object)null);
/*  928 */     add(this.attachAtomsList, (Object)null);
/*  929 */     add(this.setParameter, (Object)null);
/*  930 */     add(this.jLabel11, (Object)null);
/*  931 */     add(this.addButton, (Object)null);
/*  932 */     add(this.jLabel10, (Object)null);
/*  933 */     add(this.jLabel12, (Object)null);
/*  934 */     add(this.atomColor, (Object)null);
/*  935 */     add(this.removeButton, (Object)null);
/*  936 */     add(this.jLabel13, (Object)null);
/*  937 */     add(this.h_sign, (Object)null);
/*  938 */     add(this.k_sign, (Object)null);
/*  939 */     add(this.l_sign, (Object)null);
/*  940 */     add(this.jLabel14, (Object)null);
/*  941 */     add(this.hLabel, (Object)null);
/*  942 */     add(this.kLabel, (Object)null);
/*  943 */     add(this.lLabel, (Object)null);
/*  944 */     add(this.showPoints, (Object)null);
/*  945 */     add(this.jLabel17, (Object)null);
/*  946 */     add(this.showDirection, (Object)null);
/*  947 */     add(this.jLabel16, (Object)null);
/*  948 */     add(this.showPlane, (Object)null);
/*  949 */     add(this.jLabel19, (Object)null);
/*  950 */     add(this.customLib, (Object)null);
/*  951 */     add(this.saveButton, (Object)null);
/*  952 */     add(this.preDefineLib, (Object)null);
/*  953 */     add(this.jLabel110, (Object)null);
/*  954 */     add(this.atomSize, (Object)null);
/*  955 */     add(this.jLabel18, (Object)null);
/*  956 */     add(this.jButton2, (Object)null);
/*  957 */     add(this.jButton1, (Object)null);
/*  958 */     add(this.latticeSelect, (Object)null);
/*  959 */     add(this.jLabel1, (Object)null);
/*  960 */     add(this.blackOption, (Object)null);
/*  961 */     add(this.perspective, (Object)null);
/*  962 */     add(this.aShiftField, (Object)null);
/*  963 */     add(this.jLabel15, (Object)null);
/*  964 */     add(this.jLabel111, (Object)null);
/*  965 */     add(this.jLabel112, (Object)null);
/*  966 */     add(this.bShiftField, (Object)null);
/*  967 */     add(this.cShiftField, (Object)null);
/*  968 */     add(this.gridSlider, (Object)null);
/*  969 */     add(this.showGrid, (Object)null);
/*  970 */     add(this.showUnitGrid, (Object)null);
/*  971 */     add(this.resetButton, (Object)null);
/*      */     
/*  973 */     this.latticeSelect.addItem("Simple Cubic");
/*  974 */     this.latticeSelect.addItem("Face-Centered Cubic");
/*  975 */     this.latticeSelect.addItem("Body-Centered Cubic");
/*  976 */     this.latticeSelect.addItem("Hexagonal");
/*  977 */     this.latticeSelect.addItem("Simple Monoclinic");
/*  978 */     this.latticeSelect.addItem("Base-Centered Monoclinic");
/*  979 */     this.latticeSelect.addItem("Simple Orthorhombic");
/*  980 */     this.latticeSelect.addItem("Base-Centered Orthorhombic");
/*  981 */     this.latticeSelect.addItem("Body-Centered Orthorhombic");
/*  982 */     this.latticeSelect.addItem("Face-Centered Orthorhombic");
/*  983 */     this.latticeSelect.addItem("Simple Tetragonal");
/*  984 */     this.latticeSelect.addItem("Body-Centered Tetragonal");
/*  985 */     this.latticeSelect.addItem("Triclinic");
/*  986 */     this.latticeSelect.addItem("Trigonal");
/*      */     
/*  988 */     this.atomSize.addItem("3");
/*  989 */     this.atomSize.addItem("4");
/*  990 */     this.atomSize.addItem("5");
/*  991 */     this.atomSize.addItem("6");
/*  992 */     this.atomSize.addItem("7");
/*  993 */     this.atomSize.addItem("8");
/*  994 */     this.atomSize.addItem("9");
/*  995 */     this.atomSize.addItem("10");
/*      */   }
/*      */ 
/*      */   
/*      */   void gridSlider_stateChanged(ChangeEvent e) {
/* 1000 */     setup();
/* 1001 */     autoScale();
/*      */   }
/*      */ 
/*      */   
/*      */   void resetButton_actionPerformed(ActionEvent e) {
/* 1006 */     Transform3D t = new Transform3D();
/* 1007 */     t.rotX(Math.toRadians(-90.0D));
/* 1008 */     Transform3D t1 = new Transform3D();
/* 1009 */     t1.rotZ(Math.toRadians(-90.0D));
/* 1010 */     t.mul(t1);
/* 1011 */     Demo1 demo = (Demo1)this.demo;
/* 1012 */     demo.du.setTransform3D(t);
/*      */     
/* 1014 */     this.attachAtomsList.removeAllItems();
/* 1015 */     this.customLib.setSelectedItem(null);
/* 1016 */     this.preDefineLib.setSelectedItem(null);
/* 1017 */     this.gridSlider.setValue(2);
/* 1018 */     this.gridLabel.setText("Grid=2");
/* 1019 */     this.latticeSelect.setSelectedIndex(0);
/* 1020 */     latticeSelect_itemStateChanged(new ItemEvent(this.latticeSelect, 701, "Simple Cubic", 1));
/*      */     
/* 1022 */     autoScale();
/*      */   }
/*      */ 
/*      */   
/*      */   private void autoScale() {
/* 1027 */     Demo1 demo = (Demo1)this.demo;
/* 1028 */     Transform3D t = demo.du.getTransform3D();
/* 1029 */     t.setScale(2.0D / this.gridSlider.getValue());
/* 1030 */     demo.du.setTransform3D(t);
/*      */   }
/*      */ 
/*      */   
/*      */   void latticeSelect_itemStateChanged(ItemEvent e) {
/* 1035 */     if (this.latticeSelect.getSelectedItem().equals("Simple Cubic")) {
/*      */       
/* 1037 */       this.aField.setText("4.0");
/* 1038 */       this.bField.setText("4.0");
/* 1039 */       this.cField.setText("4.0");
/* 1040 */       this.alphaField.setText("90.0");
/* 1041 */       this.betaField.setText("90.0");
/* 1042 */       this.gammaField.setText("90.0");
/*      */     }
/* 1044 */     else if (this.latticeSelect.getSelectedItem().equals("Faced-Centered Cubic")) {
/*      */ 
/*      */       
/* 1047 */       this.aField.setText("4.0");
/* 1048 */       this.bField.setText("4.0");
/* 1049 */       this.cField.setText("4.0");
/* 1050 */       this.alphaField.setText("90.0");
/* 1051 */       this.betaField.setText("90.0");
/* 1052 */       this.gammaField.setText("90.0");
/*      */     }
/* 1054 */     else if (this.latticeSelect.getSelectedItem().equals("Body-Centered Cubic")) {
/*      */ 
/*      */       
/* 1057 */       this.aField.setText("4.0");
/* 1058 */       this.bField.setText("4.0");
/* 1059 */       this.cField.setText("4.0");
/* 1060 */       this.alphaField.setText("90.0");
/* 1061 */       this.betaField.setText("90.0");
/* 1062 */       this.gammaField.setText("90.0");
/*      */     }
/* 1064 */     else if (this.latticeSelect.getSelectedItem().equals("Hexagonal")) {
/*      */       
/* 1066 */       this.aField.setText("4.0");
/* 1067 */       this.bField.setText("4.0");
/* 1068 */       this.cField.setText("5.0");
/* 1069 */       this.alphaField.setText("90.0");
/* 1070 */       this.betaField.setText("90.0");
/* 1071 */       this.gammaField.setText("90.0");
/*      */     }
/* 1073 */     else if (this.latticeSelect.getSelectedItem().equals("Simple Monoclinic")) {
/*      */ 
/*      */       
/* 1076 */       this.aField.setText("4.0");
/* 1077 */       this.bField.setText("4.5");
/* 1078 */       this.cField.setText("5.0");
/* 1079 */       this.alphaField.setText("90.0");
/* 1080 */       this.betaField.setText("110.0");
/* 1081 */       this.gammaField.setText("90.0");
/*      */     }
/* 1083 */     else if (this.latticeSelect.getSelectedItem().equals("Base-Centered Monoclinic")) {
/*      */ 
/*      */       
/* 1086 */       this.aField.setText("4.0");
/* 1087 */       this.bField.setText("4.5");
/* 1088 */       this.cField.setText("5.0");
/* 1089 */       this.alphaField.setText("90.0");
/* 1090 */       this.betaField.setText("110.0");
/* 1091 */       this.gammaField.setText("90.0");
/*      */     }
/* 1093 */     else if (this.latticeSelect.getSelectedItem().equals("Simple Orthorhombic")) {
/*      */ 
/*      */       
/* 1096 */       this.aField.setText("4.0");
/* 1097 */       this.bField.setText("4.5");
/* 1098 */       this.cField.setText("5.0");
/* 1099 */       this.alphaField.setText("90.0");
/* 1100 */       this.betaField.setText("90.0");
/* 1101 */       this.gammaField.setText("90.0");
/*      */     }
/* 1103 */     else if (this.latticeSelect.getSelectedItem().equals("Base-Centered Orthorhombic")) {
/*      */ 
/*      */       
/* 1106 */       this.aField.setText("4.0");
/* 1107 */       this.bField.setText("4.5");
/* 1108 */       this.cField.setText("5.0");
/* 1109 */       this.alphaField.setText("90.0");
/* 1110 */       this.betaField.setText("90.0");
/* 1111 */       this.gammaField.setText("90.0");
/*      */     }
/* 1113 */     else if (this.latticeSelect.getSelectedItem().equals("Body-Centered Orthorhombic")) {
/*      */ 
/*      */       
/* 1116 */       this.aField.setText("4.0");
/* 1117 */       this.bField.setText("4.5");
/* 1118 */       this.cField.setText("5.0");
/* 1119 */       this.alphaField.setText("90.0");
/* 1120 */       this.betaField.setText("90.0");
/* 1121 */       this.gammaField.setText("90.0");
/*      */     }
/* 1123 */     else if (this.latticeSelect.getSelectedItem().equals("Face-Centered Orthorhombic")) {
/*      */ 
/*      */       
/* 1126 */       this.aField.setText("4.0");
/* 1127 */       this.bField.setText("4.5");
/* 1128 */       this.cField.setText("5.0");
/* 1129 */       this.alphaField.setText("90.0");
/* 1130 */       this.betaField.setText("90.0");
/* 1131 */       this.gammaField.setText("90.0");
/*      */     }
/* 1133 */     else if (this.latticeSelect.getSelectedItem().equals("Simple Tetragonal")) {
/*      */ 
/*      */       
/* 1136 */       this.aField.setText("4.0");
/* 1137 */       this.bField.setText("4.0");
/* 1138 */       this.cField.setText("5.0");
/* 1139 */       this.alphaField.setText("90.0");
/* 1140 */       this.betaField.setText("90.0");
/* 1141 */       this.gammaField.setText("90.0");
/*      */     }
/* 1143 */     else if (this.latticeSelect.getSelectedItem().equals("Body-Centered Tetragonal")) {
/*      */ 
/*      */       
/* 1146 */       this.aField.setText("4.0");
/* 1147 */       this.bField.setText("4.0");
/* 1148 */       this.cField.setText("5.0");
/* 1149 */       this.alphaField.setText("90.0");
/* 1150 */       this.betaField.setText("90.0");
/* 1151 */       this.gammaField.setText("90.0");
/*      */     }
/* 1153 */     else if (this.latticeSelect.getSelectedItem().equals("Triclinic")) {
/*      */       
/* 1155 */       this.aField.setText("4.0");
/* 1156 */       this.bField.setText("4.5");
/* 1157 */       this.cField.setText("5.0");
/* 1158 */       this.alphaField.setText("60.0");
/* 1159 */       this.betaField.setText("80.0");
/* 1160 */       this.gammaField.setText("110.0");
/*      */     }
/* 1162 */     else if (this.latticeSelect.getSelectedItem().equals("Trigonal")) {
/*      */       
/* 1164 */       this.aField.setText("4.0");
/* 1165 */       this.bField.setText("4.0");
/* 1166 */       this.cField.setText("4.0");
/* 1167 */       this.alphaField.setText("60.0");
/* 1168 */       this.betaField.setText("60.0");
/* 1169 */       this.gammaField.setText("60.0");
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1174 */     this.attachAtomsList.removeAllItems();
/* 1175 */     setup();
/*      */   }
/*      */ 
/*      */   
/*      */   void setParameter_mouseClicked(MouseEvent e) {
/* 1180 */     this.preDefineLib.setSelectedItem(null);
/* 1181 */     this.customLib.setSelectedItem(null);
/* 1182 */     setup();
/*      */   }
/*      */ 
/*      */   
/*      */   void h_sign_itemStateChanged(ItemEvent e) {
/* 1187 */     setup();
/*      */   }
/*      */ 
/*      */   
/*      */   void k_sign_itemStateChanged(ItemEvent e) {
/* 1192 */     setup();
/*      */   }
/*      */ 
/*      */   
/*      */   void l_sign_itemStateChanged(ItemEvent e) {
/* 1197 */     setup();
/*      */   }
/*      */ 
/*      */   
/*      */   void addButton_actionPerformed(ActionEvent e) {
/* 1202 */     double ashift = Double.parseDouble(this.aShiftField.getText());
/* 1203 */     double bshift = Double.parseDouble(this.bShiftField.getText());
/* 1204 */     double cshift = Double.parseDouble(this.cShiftField.getText());
/* 1205 */     int size = Integer.parseInt((String)this.atomSize.getSelectedItem());
/* 1206 */     Color c = this.atomColor.getColor();
/* 1207 */     String s = Integer.toHexString(c.getRGB());
/* 1208 */     s = s.substring(2);
/* 1209 */     String item = String.valueOf(String.valueOf((new StringBuffer(String.valueOf(String.valueOf(ashift)))).append(",").append(bshift).append(",").append(cshift).append(",").append(size).append(",").append(s)));
/*      */     
/* 1211 */     this.attachAtomsList.addItem(item);
/* 1212 */     this.attachAtomsList.setSelectedItem(item);
/* 1213 */     this.preDefineLib.setSelectedItem(null);
/* 1214 */     this.customLib.setSelectedItem(null);
/* 1215 */     setup();
/*      */   }
/*      */ 
/*      */   
/*      */   void removeButton_actionPerformed(ActionEvent e) {
/* 1220 */     if (this.attachAtomsList.getSelectedItem() != null) {
/*      */       
/* 1222 */       this.attachAtomsList.removeItem(this.attachAtomsList.getSelectedItem());
/*      */       
/* 1224 */       this.preDefineLib.setSelectedItem(null);
/* 1225 */       this.customLib.setSelectedItem(null);
/* 1226 */       setup();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   void preDefineLib_itemStateChanged(ItemEvent e) {
/* 1232 */     Demo1 demo = (Demo1)this.demo;
/* 1233 */     int i = this.preDefineLib.getSelectedIndex() + 1;
/* 1234 */     String name = demo.getParameter("lattice".concat(String.valueOf(String.valueOf(i))));
/* 1235 */     if (name == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1239 */     this.latticeSelect.setSelectedItem(demo.getParameter(String.valueOf(String.valueOf((new StringBuffer("lattice")).append(i).append("_lattice")))));
/*      */     
/* 1241 */     String a = demo.getParameter(String.valueOf(String.valueOf((new StringBuffer("lattice")).append(i).append("_a"))));
/* 1242 */     if (a != null)
/*      */     {
/* 1244 */       this.aField.setText(a);
/*      */     }
/* 1246 */     String b = demo.getParameter(String.valueOf(String.valueOf((new StringBuffer("lattice")).append(i).append("_b"))));
/* 1247 */     if (b != null)
/*      */     {
/* 1249 */       this.bField.setText(b);
/*      */     }
/* 1251 */     String c = demo.getParameter(String.valueOf(String.valueOf((new StringBuffer("lattice")).append(i).append("_c"))));
/* 1252 */     if (c != null)
/*      */     {
/* 1254 */       this.cField.setText(c);
/*      */     }
/* 1256 */     String alpha = demo.getParameter(String.valueOf(String.valueOf((new StringBuffer("lattice")).append(i).append("_alpha"))));
/* 1257 */     if (alpha != null)
/*      */     {
/* 1259 */       this.alphaField.setText(alpha);
/*      */     }
/* 1261 */     String beta = demo.getParameter(String.valueOf(String.valueOf((new StringBuffer("lattice")).append(i).append("_beta"))));
/* 1262 */     if (beta != null)
/*      */     {
/* 1264 */       this.betaField.setText(beta);
/*      */     }
/* 1266 */     String gamma = demo.getParameter(String.valueOf(String.valueOf((new StringBuffer("lattice")).append(i).append("_gamma"))));
/* 1267 */     if (gamma != null)
/*      */     {
/* 1269 */       this.gammaField.setText(gamma);
/*      */     }
/* 1271 */     this.attachAtomsList.removeAllItems();
/* 1272 */     for (int j = 1;; j++) {
/*      */       
/* 1274 */       String s = demo.getParameter(String.valueOf(String.valueOf((new StringBuffer("lattice")).append(i).append("_atom").append(j))));
/* 1275 */       if (s == null) {
/*      */         break;
/*      */       }
/*      */       
/* 1279 */       this.attachAtomsList.addItem(s);
/*      */     } 
/* 1281 */     this.customLib.setSelectedItem(null);
/* 1282 */     setup();
/*      */   }
/*      */   
/* 1285 */   public ParameterPanel(Demo1 demo) { this.customLibList = new Vector(10);
/* 1286 */     this.perspective = new JCheckBox();
/* 1287 */     this.jButton1 = new JButton();
/* 1288 */     this.jButton2 = new JButton();
/* 1289 */     this.blackOption = new JCheckBox();
/* 1290 */     this.jLabel15 = new JLabel();
/* 1291 */     this.jLabel111 = new JLabel();
/* 1292 */     this.jLabel112 = new JLabel(); this.demo = demo; try { jbInit(); } catch (Exception ex) { ex.printStackTrace(); }  for (int i = 1;; i++) { String name = demo.getParameter("lattice".concat(String.valueOf(String.valueOf(i)))); if (name == null) break;  this.preDefineLib.addItem(name); }  setup(); Transform3D t = new Transform3D(); t.rotX(Math.toRadians(-90.0D)); Transform3D t1 = new Transform3D(); t1.rotZ(Math.toRadians(-90.0D)); t.mul(t1); demo.du.setTransform3D(t); this.attachAtomsList.removeAllItems(); this.customLib.setSelectedItem(null); this.preDefineLib.setSelectedItem(null); this.gridSlider.setValue(2); this.gridLabel.setText("Grid=2"); this.latticeSelect.setSelectedIndex(0); latticeSelect_itemStateChanged(new ItemEvent(this.latticeSelect, 701, "Simple Cubic", 1)); autoScale(); this.showGrid.addItemListener(new ItemListener(this) { private final ParameterPanel this$0; public void itemStateChanged(ItemEvent e) { this.this$0.setup(); } }
/*      */       ); this.showUnitGrid.addItemListener(new ItemListener(this) { private final ParameterPanel this$0; public void itemStateChanged(ItemEvent e) { this.this$0.setup(); } }
/*      */       ); this.showUnitGrid.addItemListener(new ItemListener(this) { private final ParameterPanel this$0; public void itemStateChanged(ItemEvent e) { this.this$0.setup(); } }
/*      */       ); this.showDirection.addItemListener(new ItemListener(this) { private final ParameterPanel this$0; public void itemStateChanged(ItemEvent e) { this.this$0.setup(); } }
/* 1296 */       ); this.showPlane.addItemListener(new ItemListener(this) { private final ParameterPanel this$0; public void itemStateChanged(ItemEvent e) { this.this$0.setup(); } }); this.hLabel.addMouseListener(new MouseAdapter(this) { private final ParameterPanel this$0; public void mouseClicked(MouseEvent e) { if (e.getModifiers() == 16) { int x = (new Integer(this.this$0.hLabel.getText())).intValue(); x++; if (x > 9) x = 9;  this.this$0.hLabel.setText(String.valueOf(x)); } else if (e.getModifiers() == 4) { int x = (new Integer(this.this$0.hLabel.getText())).intValue(); x--; if (x < 0) x = 0;  this.this$0.hLabel.setText(String.valueOf(x)); }  this.this$0.setup(); } }); this.kLabel.addMouseListener(new MouseAdapter(this) { private final ParameterPanel this$0; public void mouseClicked(MouseEvent e) { if (e.getModifiers() == 16) { int x = (new Integer(this.this$0.kLabel.getText())).intValue(); x++; if (x > 9) x = 9;  this.this$0.kLabel.setText(String.valueOf(x)); } else if (e.getModifiers() == 4) { int x = (new Integer(this.this$0.kLabel.getText())).intValue(); x--; if (x < 0) x = 0;  this.this$0.kLabel.setText(String.valueOf(x)); }  this.this$0.setup(); } }); this.lLabel.addMouseListener(new MouseAdapter(this) { private final ParameterPanel this$0; public void mouseClicked(MouseEvent e) { if (e.getModifiers() == 16) { int x = (new Integer(this.this$0.lLabel.getText())).intValue(); x++; if (x > 9) x = 9;  this.this$0.lLabel.setText(String.valueOf(x)); } else if (e.getModifiers() == 4) { int x = (new Integer(this.this$0.lLabel.getText())).intValue(); x--; if (x < 0) x = 0;  this.this$0.lLabel.setText(String.valueOf(x)); }  this.this$0.setup(); } }); } void saveButton_actionPerformed(ActionEvent e) { if (this.attachAtomsList.getItemCount() != 0) {
/*      */       
/* 1298 */       CrystalInfo ci = new CrystalInfo(this);
/* 1299 */       ci.lattice = this.latticeSelect.getSelectedItem().toString();
/* 1300 */       ci.a = this.aField.getText();
/* 1301 */       ci.b = this.bField.getText();
/* 1302 */       ci.c = this.cField.getText();
/* 1303 */       ci.alpha = this.alphaField.getText();
/* 1304 */       ci.beta = this.betaField.getText();
/* 1305 */       ci.gamma = this.gammaField.getText();
/* 1306 */       for (int i = 0; i < this.attachAtomsList.getItemCount(); i++)
/*      */       {
/* 1308 */         ci.atoms.add(this.attachAtomsList.getItemAt(i));
/*      */       }
/* 1310 */       this.customLibList.add(ci);
/* 1311 */       this.customLib.addItem(String.valueOf(this.customLibList.size() - 1));
/*      */     }  }
/*      */ 
/*      */ 
/*      */   
/*      */   void customLib_itemStateChanged(ItemEvent e) {
/* 1317 */     String str = (String)this.customLib.getSelectedItem();
/* 1318 */     if (str != null) {
/*      */       
/* 1320 */       int index = Integer.parseInt(str);
/* 1321 */       CrystalInfo ci = this.customLibList.get(index);
/* 1322 */       this.latticeSelect.setSelectedItem(ci.lattice);
/* 1323 */       this.aField.setText(ci.a);
/* 1324 */       this.bField.setText(ci.b);
/* 1325 */       this.cField.setText(ci.c);
/* 1326 */       this.alphaField.setText(ci.alpha);
/* 1327 */       this.betaField.setText(ci.beta);
/* 1328 */       this.gammaField.setText(ci.gamma);
/* 1329 */       this.attachAtomsList.removeAllItems();
/* 1330 */       for (int i = 0; i < ci.atoms.size(); i++)
/*      */       {
/* 1332 */         this.attachAtomsList.addItem(ci.atoms.get(i));
/*      */       }
/*      */     } 
/* 1335 */     this.preDefineLib.setSelectedItem(null);
/* 1336 */     setup();
/*      */   }
/*      */ 
/*      */   
/*      */   void perspective_itemStateChanged(ItemEvent e) {
/* 1341 */     Demo1 demo = (Demo1)this.demo;
/* 1342 */     if (e.getStateChange() == 1)
/*      */     {
/* 1344 */       demo.du.getUniverse().getViewer().getView().setProjectionPolicy(1);
/*      */     }
/*      */     
/* 1347 */     if (e.getStateChange() == 2)
/*      */     {
/* 1349 */       demo.du.getUniverse().getViewer().getView().setProjectionPolicy(0);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void blackOption_itemStateChanged(ItemEvent e) {
/* 1356 */     Demo1 demo = (Demo1)this.demo;
/* 1357 */     if (e.getStateChange() == 1)
/*      */     {
/* 1359 */       demo.du.getUniverseBackground().setColor(new Color3f(Color.black));
/*      */     }
/* 1361 */     if (e.getStateChange() == 2)
/*      */     {
/* 1363 */       demo.du.getUniverseBackground().setColor(new Color3f(Color.white));
/*      */     }
/*      */   }
/*      */ }


/* Location:              C:\Users\Evgeniy\IdeaProjects\modern-lab-comp-applets\src\Lab_1\Cell & Properties\\\unitcell21.jar!\ParameterPanel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */