/*      */ import java.awt.Color;
/*      */ import javax.media.j3d.Appearance;
/*      */ import javax.media.j3d.Node;
/*      */ import javax.media.j3d.PolygonAttributes;
/*      */ import javax.media.j3d.Transform3D;
/*      */ import javax.media.j3d.TransformGroup;
/*      */ import javax.vecmath.Tuple3d;
/*      */ import javax.vecmath.Vector3d;
/*      */ 
/*      */ public class Crystal extends BranchGroup {
/*      */   private Lattice lattice;
/*      */   private int gridNum;
/*   13 */   private BranchGroup atomBranch = null; private AtomInfo[] attachedAtomInfos; private Vector3d[] atomShifts;
/*   14 */   private BranchGroup gridBranch = null;
/*   15 */   private BranchGroup singleCellBranch = null;
/*   16 */   private BranchGroup latticePointBranch = null;
/*   17 */   private BranchGroup planeBranch = null;
/*   18 */   private BranchGroup directionBranch = null;
/*      */   
/*   20 */   private float singleCellGridWidth = 0.008F;
/*   21 */   private float gridWidth = 0.003F;
/*   22 */   private Color latticePointColor = Color.lightGray;
/*   23 */   private float latticePointSize = 0.01F;
/*      */ 
/*      */   
/*      */   private Demo1 demo;
/*      */ 
/*      */   
/*      */   public Crystal(Lattice lattice, int gridNum, AtomInfo[] attachedAtomInfos, Vector3d[] atomShifts, Demo1 demo) {
/*   30 */     this.demo = demo;
/*   31 */     this.lattice = lattice;
/*   32 */     this.gridNum = gridNum;
/*   33 */     this.attachedAtomInfos = attachedAtomInfos;
/*   34 */     this.atomShifts = atomShifts;
/*   35 */     createCrystal();
/*      */   }
/*      */ 
/*      */   
/*      */   private void createCrystal() {
/*   40 */     addAtomsBranch();
/*   41 */     addGridBranch();
/*   42 */     addSingleCellBranch();
/*   43 */     addLatticePointBranch();
/*      */   }
/*      */ 
/*      */   
/*      */   public void addPlaneBranch(int hh, int kk, int ll) {
/*   48 */     removePlaneBranch();
/*   49 */     this.planeBranch = new BranchGroup();
/*   50 */     this; this.planeBranch.setCapability(17);
/*      */     
/*   52 */     int h = Math.abs(hh);
/*   53 */     int k = Math.abs(kk);
/*   54 */     int l = Math.abs(ll);
/*   55 */     if (h == 0 && k == 0 && l == 0) {
/*      */       return;
/*      */     }
/*      */     
/*   59 */     if (h != 0 && k == 0 && l == 0) {
/*      */       
/*   61 */       int num = this.gridNum * Math.abs(h) + 1;
/*   62 */       double step = 1.0D / Math.abs(h);
/*      */       
/*   64 */       for (int i = 0; i < num; i++)
/*      */       {
/*   66 */         double[] x = new double[4];
/*   67 */         double[] y = new double[4];
/*   68 */         double[] z = new double[4];
/*      */         
/*   70 */         x[0] = i * step;
/*   71 */         y[0] = 0.0D;
/*   72 */         z[0] = 0.0D;
/*      */         
/*   74 */         x[1] = x[0];
/*   75 */         y[1] = this.gridNum;
/*   76 */         z[1] = 0.0D;
/*      */         
/*   78 */         x[2] = x[0];
/*   79 */         y[2] = this.gridNum;
/*   80 */         z[2] = this.gridNum;
/*      */         
/*   82 */         x[3] = x[0];
/*   83 */         y[3] = 0.0D;
/*   84 */         z[3] = this.gridNum;
/*      */         
/*   86 */         QuadArray qa = new QuadArray(4, 1);
/*   87 */         Vector3d[] v = new Vector3d[4];
/*   88 */         for (int j = 0; j < 4; j++) {
/*      */           
/*   90 */           v[j] = new Vector3d(x[j], y[j], z[j]);
/*   91 */           v[j] = shiftToCenter(v[j], this.gridNum);
/*   92 */           v[j] = this.lattice.coordinateConvert(v[j]);
/*   93 */           v[j].scale(Logic.scale);
/*   94 */           qa.setCoordinate(j, new Point3d((Tuple3d)v[j]));
/*      */         } 
/*   96 */         Appearance app = new Appearance();
/*   97 */         app.setTransparencyAttributes(new TransparencyAttributes(2, Logic.planeAlpha));
/*   98 */         app.setColoringAttributes(new ColoringAttributes(new Color3f(Color.lightGray), 3));
/*   99 */         PolygonAttributes pa = new PolygonAttributes();
/*  100 */         pa.setCullFace(0);
/*  101 */         app.setPolygonAttributes(pa);
/*  102 */         Shape3D shape = new Shape3D((Geometry)qa, app);
/*  103 */         this.planeBranch.addChild((Node)shape);
/*      */       }
/*      */     
/*  106 */     } else if (h == 0 && k != 0 && l == 0) {
/*      */       
/*  108 */       int num = this.gridNum * Math.abs(k) + 1;
/*  109 */       double step = 1.0D / Math.abs(k);
/*      */       
/*  111 */       for (int i = 0; i < num; i++)
/*      */       {
/*  113 */         double[] x = new double[4];
/*  114 */         double[] y = new double[4];
/*  115 */         double[] z = new double[4];
/*      */         
/*  117 */         x[0] = 0.0D;
/*  118 */         y[0] = i * step;
/*  119 */         z[0] = 0.0D;
/*      */         
/*  121 */         x[1] = 0.0D;
/*  122 */         y[1] = y[0];
/*  123 */         z[1] = this.gridNum;
/*      */         
/*  125 */         x[2] = this.gridNum;
/*  126 */         y[2] = y[0];
/*  127 */         z[2] = this.gridNum;
/*      */         
/*  129 */         x[3] = this.gridNum;
/*  130 */         y[3] = y[0];
/*  131 */         z[3] = 0.0D;
/*      */         
/*  133 */         QuadArray qa = new QuadArray(4, 1);
/*      */         
/*  135 */         Vector3d[] v = new Vector3d[4];
/*  136 */         for (int j = 0; j < 4; j++) {
/*      */           
/*  138 */           v[j] = new Vector3d(x[j], y[j], z[j]);
/*  139 */           v[j] = shiftToCenter(v[j], this.gridNum);
/*  140 */           v[j] = this.lattice.coordinateConvert(v[j]);
/*  141 */           v[j].scale(Logic.scale);
/*  142 */           qa.setCoordinate(j, new Point3d((Tuple3d)v[j]));
/*      */         } 
/*  144 */         Appearance app = new Appearance();
/*  145 */         app.setTransparencyAttributes(new TransparencyAttributes(2, Logic.planeAlpha));
/*  146 */         app.setColoringAttributes(new ColoringAttributes(new Color3f(Color.lightGray), 3));
/*  147 */         PolygonAttributes pa = new PolygonAttributes();
/*  148 */         pa.setCullFace(0);
/*  149 */         app.setPolygonAttributes(pa);
/*  150 */         Shape3D shape = new Shape3D((Geometry)qa, app);
/*  151 */         this.planeBranch.addChild((Node)shape);
/*      */       }
/*      */     
/*  154 */     } else if (h == 0 && k == 0 && l != 0) {
/*      */       
/*  156 */       int num = this.gridNum * Math.abs(l) + 1;
/*  157 */       double step = 1.0D / Math.abs(l);
/*      */       
/*  159 */       for (int i = 0; i < num; i++)
/*      */       {
/*  161 */         double[] x = new double[4];
/*  162 */         double[] y = new double[4];
/*  163 */         double[] z = new double[4];
/*      */         
/*  165 */         x[0] = 0.0D;
/*  166 */         y[0] = 0.0D;
/*  167 */         z[0] = i * step;
/*      */         
/*  169 */         x[1] = this.gridNum;
/*  170 */         y[1] = 0.0D;
/*  171 */         z[1] = z[0];
/*      */         
/*  173 */         x[2] = this.gridNum;
/*  174 */         y[2] = this.gridNum;
/*  175 */         z[2] = z[0];
/*      */         
/*  177 */         x[3] = 0.0D;
/*  178 */         y[3] = this.gridNum;
/*  179 */         z[3] = z[0];
/*      */         
/*  181 */         QuadArray qa = new QuadArray(4, 1);
/*      */         
/*  183 */         Vector3d[] v = new Vector3d[4];
/*  184 */         for (int j = 0; j < 4; j++) {
/*      */           
/*  186 */           v[j] = new Vector3d(x[j], y[j], z[j]);
/*  187 */           v[j] = shiftToCenter(v[j], this.gridNum);
/*  188 */           v[j] = this.lattice.coordinateConvert(v[j]);
/*  189 */           v[j].scale(Logic.scale);
/*  190 */           qa.setCoordinate(j, new Point3d((Tuple3d)v[j]));
/*      */         } 
/*  192 */         Appearance app = new Appearance();
/*  193 */         app.setTransparencyAttributes(new TransparencyAttributes(2, Logic.planeAlpha));
/*  194 */         app.setColoringAttributes(new ColoringAttributes(new Color3f(Color.lightGray), 3));
/*  195 */         PolygonAttributes pa = new PolygonAttributes();
/*  196 */         pa.setCullFace(0);
/*  197 */         app.setPolygonAttributes(pa);
/*  198 */         Shape3D shape = new Shape3D((Geometry)qa, app);
/*  199 */         this.planeBranch.addChild((Node)shape);
/*      */       }
/*      */     
/*      */     }
/*  203 */     else if (h != 0 && k != 0 && l == 0) {
/*      */ 
/*      */       
/*  206 */       int num = h * this.gridNum + k * this.gridNum - 1;
/*      */       
/*  208 */       for (int i = 1; i <= num; i++)
/*      */       {
/*  210 */         Vector3d v1 = new Vector3d((hh / h * 1), 0.0D, 0.0D);
/*  211 */         Vector3d v2 = new Vector3d(0.0D, (kk / k * 1), 0.0D);
/*  212 */         Vector3d shifts = new Vector3d(((hh / h == -1) ? this.gridNum : false), ((kk / k == -1) ? this.gridNum : false), 0.0D);
/*  213 */         Vector3d z = new Vector3d(0.0D, 0.0D, this.gridNum);
/*      */         
/*  215 */         Vector3d vv1 = new Vector3d(v1);
/*  216 */         vv1.scale(1.0D / h);
/*  217 */         vv1.scale(((i > this.gridNum * h) ? (h * this.gridNum) : i));
/*      */         
/*  219 */         Vector3d vv2 = new Vector3d(v2);
/*  220 */         vv2.scale(1.0D / k);
/*  221 */         vv2.scale(((i > this.gridNum * h) ? (i - this.gridNum * h) : false));
/*      */         
/*  223 */         Vector3d vvv1 = new Vector3d(vv1);
/*  224 */         vvv1.add((Tuple3d)vv2);
/*  225 */         vvv1.add((Tuple3d)shifts);
/*      */ 
/*      */         
/*  228 */         vv2 = new Vector3d(v2);
/*  229 */         vv2.scale(1.0D / k);
/*  230 */         vv2.scale(((i > this.gridNum * k) ? (k * this.gridNum) : i));
/*      */         
/*  232 */         vv1 = new Vector3d(v1);
/*  233 */         vv1.scale(1.0D / h);
/*  234 */         vv1.scale(((i > this.gridNum * k) ? (i - this.gridNum * k) : false));
/*      */         
/*  236 */         Vector3d vvv2 = new Vector3d(vv2);
/*  237 */         vvv2.add((Tuple3d)vv1);
/*  238 */         vvv2.add((Tuple3d)shifts);
/*      */         
/*  240 */         QuadArray qa = new QuadArray(4, 1);
/*  241 */         Vector3d[] v = new Vector3d[4];
/*  242 */         v[0] = new Vector3d(vvv1);
/*      */         
/*  244 */         v[1] = new Vector3d(vvv2);
/*      */         
/*  246 */         v[2] = new Vector3d(vvv2);
/*  247 */         v[2].add((Tuple3d)z);
/*      */         
/*  249 */         v[3] = new Vector3d(vvv1);
/*  250 */         v[3].add((Tuple3d)z);
/*      */         
/*  252 */         for (int j = 0; j < 4; j++) {
/*      */           
/*  254 */           v[j] = shiftToCenter(v[j], this.gridNum);
/*  255 */           v[j] = this.lattice.coordinateConvert(v[j]);
/*  256 */           v[j].scale(Logic.scale);
/*  257 */           qa.setCoordinate(j, new Point3d((Tuple3d)v[j]));
/*      */         } 
/*      */         
/*  260 */         Appearance app = new Appearance();
/*  261 */         app.setTransparencyAttributes(new TransparencyAttributes(2, Logic.planeAlpha));
/*  262 */         app.setColoringAttributes(new ColoringAttributes(new Color3f(Color.lightGray), 3));
/*  263 */         PolygonAttributes pa = new PolygonAttributes();
/*  264 */         pa.setCullFace(0);
/*  265 */         app.setPolygonAttributes(pa);
/*  266 */         Shape3D shape = new Shape3D((Geometry)qa, app);
/*  267 */         this.planeBranch.addChild((Node)shape);
/*      */       }
/*      */     
/*  270 */     } else if (h != 0 && k == 0 && l != 0) {
/*      */       
/*  272 */       int num = h * this.gridNum + l * this.gridNum - 1;
/*      */       
/*  274 */       for (int i = 1; i <= num; i++)
/*      */       {
/*  276 */         Vector3d v1 = new Vector3d((hh / h * 1), 0.0D, 0.0D);
/*  277 */         Vector3d v2 = new Vector3d(0.0D, 0.0D, (ll / l * 1));
/*  278 */         Vector3d shifts = new Vector3d(((hh / h == -1) ? this.gridNum : false), 0.0D, ((ll / l == -1) ? this.gridNum : false));
/*  279 */         Vector3d y = new Vector3d(0.0D, this.gridNum, 0.0D);
/*      */         
/*  281 */         Vector3d vv1 = new Vector3d(v1);
/*  282 */         vv1.scale(1.0D / h);
/*  283 */         vv1.scale(((i > this.gridNum * h) ? (h * this.gridNum) : i));
/*      */         
/*  285 */         Vector3d vv2 = new Vector3d(v2);
/*  286 */         vv2.scale(1.0D / l);
/*  287 */         vv2.scale(((i > this.gridNum * h) ? (i - this.gridNum * h) : false));
/*      */         
/*  289 */         Vector3d vvv1 = new Vector3d(vv1);
/*  290 */         vvv1.add((Tuple3d)vv2);
/*  291 */         vvv1.add((Tuple3d)shifts);
/*      */         
/*  293 */         vv2 = new Vector3d(v2);
/*  294 */         vv2.scale(1.0D / l);
/*  295 */         vv2.scale(((i > this.gridNum * l) ? (l * this.gridNum) : i));
/*      */         
/*  297 */         vv1 = new Vector3d(v1);
/*  298 */         vv1.scale(1.0D / h);
/*  299 */         vv1.scale(((i > this.gridNum * l) ? (i - this.gridNum * l) : false));
/*      */         
/*  301 */         Vector3d vvv2 = new Vector3d(vv2);
/*  302 */         vvv2.add((Tuple3d)vv1);
/*  303 */         vvv2.add((Tuple3d)shifts);
/*      */         
/*  305 */         QuadArray qa = new QuadArray(4, 1);
/*  306 */         Vector3d[] v = new Vector3d[4];
/*  307 */         v[0] = new Vector3d(vvv1);
/*      */         
/*  309 */         v[1] = new Vector3d(vvv2);
/*      */         
/*  311 */         v[2] = new Vector3d(vvv2);
/*  312 */         v[2].add((Tuple3d)y);
/*      */         
/*  314 */         v[3] = new Vector3d(vvv1);
/*  315 */         v[3].add((Tuple3d)y);
/*      */         
/*  317 */         for (int j = 0; j < 4; j++) {
/*      */           
/*  319 */           v[j] = shiftToCenter(v[j], this.gridNum);
/*  320 */           v[j] = this.lattice.coordinateConvert(v[j]);
/*  321 */           v[j].scale(Logic.scale);
/*  322 */           qa.setCoordinate(j, new Point3d((Tuple3d)v[j]));
/*      */         } 
/*      */         
/*  325 */         Appearance app = new Appearance();
/*  326 */         app.setTransparencyAttributes(new TransparencyAttributes(2, Logic.planeAlpha));
/*  327 */         app.setColoringAttributes(new ColoringAttributes(new Color3f(Color.lightGray), 3));
/*  328 */         PolygonAttributes pa = new PolygonAttributes();
/*  329 */         pa.setCullFace(0);
/*  330 */         app.setPolygonAttributes(pa);
/*  331 */         Shape3D shape = new Shape3D((Geometry)qa, app);
/*  332 */         this.planeBranch.addChild((Node)shape);
/*      */       }
/*      */     
/*  335 */     } else if (h == 0 && k != 0 && l != 0) {
/*      */       
/*  337 */       int num = k * this.gridNum + l * this.gridNum - 1;
/*      */       
/*  339 */       for (int i = 1; i <= num; i++)
/*      */       {
/*  341 */         Vector3d v1 = new Vector3d(0.0D, 1.0D, 0.0D);
/*  342 */         Vector3d v2 = new Vector3d(0.0D, 0.0D, 1.0D);
/*  343 */         Vector3d shifts = new Vector3d(0.0D, ((kk / k == -1) ? this.gridNum : false), ((ll / l == -1) ? this.gridNum : false));
/*  344 */         Vector3d x = new Vector3d(this.gridNum, 0.0D, 0.0D);
/*      */         
/*  346 */         Vector3d vv1 = new Vector3d(v1);
/*  347 */         vv1.scale(1.0D / k);
/*  348 */         vv1.scale(((i > this.gridNum * k) ? (k * this.gridNum) : i));
/*      */         
/*  350 */         Vector3d vv2 = new Vector3d(v2);
/*  351 */         vv2.scale(1.0D / l);
/*  352 */         vv2.scale(((i > this.gridNum * k) ? (i - this.gridNum * k) : false));
/*      */         
/*  354 */         Vector3d vvv1 = new Vector3d(vv1);
/*  355 */         vvv1.add((Tuple3d)vv2);
/*  356 */         vvv1.add((Tuple3d)shifts);
/*      */         
/*  358 */         vv2 = new Vector3d(v2);
/*  359 */         vv2.scale(1.0D / l);
/*  360 */         vv2.scale(((i > this.gridNum * l) ? (l * this.gridNum) : i));
/*      */         
/*  362 */         vv1 = new Vector3d(v1);
/*  363 */         vv1.scale(1.0D / k);
/*  364 */         vv1.scale(((i > this.gridNum * l) ? (i - this.gridNum * l) : false));
/*      */         
/*  366 */         Vector3d vvv2 = new Vector3d(vv2);
/*  367 */         vvv2.add((Tuple3d)vv1);
/*  368 */         vvv2.add((Tuple3d)shifts);
/*      */         
/*  370 */         QuadArray qa = new QuadArray(4, 1);
/*  371 */         Vector3d[] v = new Vector3d[4];
/*  372 */         v[0] = new Vector3d(vvv1);
/*      */         
/*  374 */         v[1] = new Vector3d(vvv2);
/*      */         
/*  376 */         v[2] = new Vector3d(vvv2);
/*  377 */         v[2].add((Tuple3d)x);
/*      */         
/*  379 */         v[3] = new Vector3d(vvv1);
/*  380 */         v[3].add((Tuple3d)x);
/*      */         
/*  382 */         for (int j = 0; j < 4; j++) {
/*      */           
/*  384 */           v[j] = shiftToCenter(v[j], this.gridNum);
/*  385 */           v[j] = this.lattice.coordinateConvert(v[j]);
/*  386 */           v[j].scale(Logic.scale);
/*  387 */           qa.setCoordinate(j, new Point3d((Tuple3d)v[j]));
/*      */         } 
/*      */         
/*  390 */         Appearance app = new Appearance();
/*  391 */         app.setTransparencyAttributes(new TransparencyAttributes(2, Logic.planeAlpha));
/*  392 */         app.setColoringAttributes(new ColoringAttributes(new Color3f(Color.lightGray), 3));
/*  393 */         PolygonAttributes pa = new PolygonAttributes();
/*  394 */         pa.setCullFace(0);
/*  395 */         app.setPolygonAttributes(pa);
/*  396 */         Shape3D shape = new Shape3D((Geometry)qa, app);
/*  397 */         this.planeBranch.addChild((Node)shape);
/*      */       }
/*      */     
/*  400 */     } else if (h != 0 && k != 0 && l != 0) {
/*      */       
/*  402 */       int num = h * this.gridNum + k * this.gridNum + l * this.gridNum - 1;
/*  403 */       Vector3d shifts = new Vector3d(((hh / h == -1) ? this.gridNum : false), ((kk / k == -1) ? this.gridNum : false), ((ll / l == -1) ? this.gridNum : false));
/*  404 */       for (int i = 1; i <= num; i++) {
/*      */         
/*  406 */         Vector3d v1 = new Vector3d((hh / h * 1), 0.0D, 0.0D);
/*  407 */         Vector3d v2 = new Vector3d(0.0D, (kk / k * 1), 0.0D);
/*  408 */         Vector3d v3 = new Vector3d(0.0D, 0.0D, (ll / l * 1));
/*      */         
/*  410 */         Vector3d vv1 = new Vector3d(v1);
/*  411 */         Vector3d vv2 = new Vector3d(v2);
/*  412 */         Vector3d vv3 = new Vector3d(v3);
/*      */         
/*  414 */         vv1.scale(1.0D / h);
/*  415 */         vv2.scale(1.0D / k);
/*  416 */         vv3.scale(1.0D / l);
/*      */         
/*  418 */         vv1.scale(((i > h * this.gridNum) ? (h * this.gridNum) : i));
/*  419 */         vv3.scale(((i > h * this.gridNum) ? ((i - h * this.gridNum > l * this.gridNum) ? (l * this.gridNum) : (i - h * this.gridNum)) : false));
/*  420 */         vv2.scale(((i > h * this.gridNum) ? ((i - h * this.gridNum > l * this.gridNum) ? ((i - h * this.gridNum - l * this.gridNum > k * this.gridNum) ? (k * this.gridNum) : (i - h * this.gridNum - l * this.gridNum)) : false) : false));
/*      */         
/*  422 */         Vector3d vvv1 = new Vector3d(vv1);
/*  423 */         vvv1.add((Tuple3d)vv3);
/*  424 */         vvv1.add((Tuple3d)vv2);
/*  425 */         vvv1.add((Tuple3d)shifts);
/*  426 */         vvv1 = shiftToCenter(vvv1, this.gridNum);
/*  427 */         vvv1 = this.lattice.coordinateConvert(vvv1);
/*  428 */         vvv1.scale(Logic.scale);
/*      */         
/*  430 */         vv1 = new Vector3d(v1);
/*  431 */         vv2 = new Vector3d(v2);
/*  432 */         vv3 = new Vector3d(v3);
/*      */         
/*  434 */         vv1.scale(1.0D / h);
/*  435 */         vv2.scale(1.0D / k);
/*  436 */         vv3.scale(1.0D / l);
/*      */         
/*  438 */         vv1.scale(((i > h * this.gridNum) ? (h * this.gridNum) : i));
/*  439 */         vv2.scale(((i > h * this.gridNum) ? ((i - h * this.gridNum > k * this.gridNum) ? (k * this.gridNum) : (i - h * this.gridNum)) : false));
/*  440 */         vv3.scale(((i > h * this.gridNum) ? ((i - h * this.gridNum > k * this.gridNum) ? ((i - h * this.gridNum - k * this.gridNum > l * this.gridNum) ? (l * this.gridNum) : (i - h * this.gridNum - k * this.gridNum)) : false) : false));
/*      */         
/*  442 */         Vector3d vvv2 = new Vector3d(vv1);
/*  443 */         vvv2.add((Tuple3d)vv2);
/*  444 */         vvv2.add((Tuple3d)vv3);
/*  445 */         vvv2.add((Tuple3d)shifts);
/*  446 */         vvv2 = shiftToCenter(vvv2, this.gridNum);
/*  447 */         vvv2 = this.lattice.coordinateConvert(vvv2);
/*  448 */         vvv2.scale(Logic.scale);
/*      */ 
/*      */         
/*  451 */         vv1 = new Vector3d(v1);
/*  452 */         vv2 = new Vector3d(v2);
/*  453 */         vv3 = new Vector3d(v3);
/*      */         
/*  455 */         vv1.scale(1.0D / h);
/*  456 */         vv2.scale(1.0D / k);
/*  457 */         vv3.scale(1.0D / l);
/*      */         
/*  459 */         vv2.scale(((i > k * this.gridNum) ? (k * this.gridNum) : i));
/*  460 */         vv1.scale(((i > k * this.gridNum) ? ((i - k * this.gridNum > h * this.gridNum) ? (h * this.gridNum) : (i - k * this.gridNum)) : false));
/*  461 */         vv3.scale(((i > k * this.gridNum) ? ((i - k * this.gridNum > h * this.gridNum) ? ((i - k * this.gridNum - h * this.gridNum > l * this.gridNum) ? (l * this.gridNum) : (i - k * this.gridNum - h * this.gridNum)) : false) : false));
/*      */         
/*  463 */         Vector3d vvv3 = new Vector3d(vv1);
/*  464 */         vvv3.add((Tuple3d)vv2);
/*  465 */         vvv3.add((Tuple3d)vv3);
/*  466 */         vvv3.add((Tuple3d)shifts);
/*  467 */         vvv3 = shiftToCenter(vvv3, this.gridNum);
/*  468 */         vvv3 = this.lattice.coordinateConvert(vvv3);
/*  469 */         vvv3.scale(Logic.scale);
/*      */ 
/*      */         
/*  472 */         vv1 = new Vector3d(v1);
/*  473 */         vv2 = new Vector3d(v2);
/*  474 */         vv3 = new Vector3d(v3);
/*      */         
/*  476 */         vv1.scale(1.0D / h);
/*  477 */         vv2.scale(1.0D / k);
/*  478 */         vv3.scale(1.0D / l);
/*      */         
/*  480 */         vv2.scale(((i > k * this.gridNum) ? (k * this.gridNum) : i));
/*  481 */         vv3.scale(((i > k * this.gridNum) ? ((i - k * this.gridNum > l * this.gridNum) ? (l * this.gridNum) : (i - k * this.gridNum)) : false));
/*  482 */         vv1.scale(((i > k * this.gridNum) ? ((i - k * this.gridNum > l * this.gridNum) ? ((i - k * this.gridNum - l * this.gridNum > h * this.gridNum) ? (h * this.gridNum) : (i - k * this.gridNum - l * this.gridNum)) : false) : false));
/*      */         
/*  484 */         Vector3d vvv4 = new Vector3d(vv1);
/*  485 */         vvv4.add((Tuple3d)vv2);
/*  486 */         vvv4.add((Tuple3d)vv3);
/*  487 */         vvv4.add((Tuple3d)shifts);
/*  488 */         vvv4 = shiftToCenter(vvv4, this.gridNum);
/*  489 */         vvv4 = this.lattice.coordinateConvert(vvv4);
/*  490 */         vvv4.scale(Logic.scale);
/*      */ 
/*      */         
/*  493 */         vv1 = new Vector3d(v1);
/*  494 */         vv2 = new Vector3d(v2);
/*  495 */         vv3 = new Vector3d(v3);
/*      */         
/*  497 */         vv1.scale(1.0D / h);
/*  498 */         vv2.scale(1.0D / k);
/*  499 */         vv3.scale(1.0D / l);
/*      */         
/*  501 */         vv3.scale(((i > l * this.gridNum) ? (l * this.gridNum) : i));
/*  502 */         vv2.scale(((i > l * this.gridNum) ? ((i - l * this.gridNum > k * this.gridNum) ? (k * this.gridNum) : (i - l * this.gridNum)) : false));
/*  503 */         vv1.scale(((i > l * this.gridNum) ? ((i - l * this.gridNum > k * this.gridNum) ? ((i - l * this.gridNum - k * this.gridNum > h * this.gridNum) ? (h * this.gridNum) : (i - l * this.gridNum - k * this.gridNum)) : false) : false));
/*      */         
/*  505 */         Vector3d vvv5 = new Vector3d(vv1);
/*  506 */         vvv5.add((Tuple3d)vv2);
/*  507 */         vvv5.add((Tuple3d)vv3);
/*  508 */         vvv5.add((Tuple3d)shifts);
/*  509 */         vvv5 = shiftToCenter(vvv5, this.gridNum);
/*  510 */         vvv5 = this.lattice.coordinateConvert(vvv5);
/*  511 */         vvv5.scale(Logic.scale);
/*      */ 
/*      */         
/*  514 */         vv1 = new Vector3d(v1);
/*  515 */         vv2 = new Vector3d(v2);
/*  516 */         vv3 = new Vector3d(v3);
/*      */         
/*  518 */         vv1.scale(1.0D / h);
/*  519 */         vv2.scale(1.0D / k);
/*  520 */         vv3.scale(1.0D / l);
/*      */         
/*  522 */         vv3.scale(((i > l * this.gridNum) ? (l * this.gridNum) : i));
/*  523 */         vv1.scale(((i > l * this.gridNum) ? ((i - l * this.gridNum > h * this.gridNum) ? (h * this.gridNum) : (i - l * this.gridNum)) : false));
/*  524 */         vv2.scale(((i > l * this.gridNum) ? ((i - l * this.gridNum > h * this.gridNum) ? ((i - l * this.gridNum - h * this.gridNum > k * this.gridNum) ? (k * this.gridNum) : (i - l * this.gridNum - h * this.gridNum)) : false) : false));
/*      */         
/*  526 */         Vector3d vvv6 = new Vector3d(vv1);
/*  527 */         vvv6.add((Tuple3d)vv2);
/*  528 */         vvv6.add((Tuple3d)vv3);
/*  529 */         vvv6.add((Tuple3d)shifts);
/*  530 */         vvv6 = shiftToCenter(vvv6, this.gridNum);
/*  531 */         vvv6 = this.lattice.coordinateConvert(vvv6);
/*  532 */         vvv6.scale(Logic.scale);
/*      */ 
/*      */         
/*  535 */         int[] counts = new int[1];
/*  536 */         counts[0] = 6;
/*  537 */         TriangleFanArray tfa = new TriangleFanArray(6, 1, counts);
/*  538 */         tfa.setCoordinate(0, new Point3d((Tuple3d)vvv1));
/*  539 */         tfa.setCoordinate(1, new Point3d((Tuple3d)vvv2));
/*  540 */         tfa.setCoordinate(2, new Point3d((Tuple3d)vvv3));
/*  541 */         tfa.setCoordinate(3, new Point3d((Tuple3d)vvv4));
/*  542 */         tfa.setCoordinate(4, new Point3d((Tuple3d)vvv5));
/*  543 */         tfa.setCoordinate(5, new Point3d((Tuple3d)vvv6));
/*      */         
/*  545 */         Appearance app = new Appearance();
/*  546 */         PolygonAttributes pa = new PolygonAttributes();
/*  547 */         pa.setCullFace(0);
/*  548 */         app.setPolygonAttributes(pa);
/*  549 */         app.setTransparencyAttributes(new TransparencyAttributes(2, Logic.planeAlpha));
/*  550 */         app.setColoringAttributes(new ColoringAttributes(new Color3f(Color.lightGray), 3));
/*  551 */         Shape3D shape = new Shape3D((Geometry)tfa, app);
/*  552 */         this.planeBranch.addChild((Node)shape);
/*      */       } 
/*      */     } 
/*  555 */     this.planeBranch.compile();
/*  556 */     addChild((Node)this.planeBranch);
/*      */   }
/*      */ 
/*      */   
/*      */   public void removePlaneBranch() {
/*  561 */     if (this.planeBranch != null) {
/*      */       
/*  563 */       removeChild((Node)this.planeBranch);
/*  564 */       this.planeBranch.detach();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void addDirectionBranch(int h, int k, int l) {
/*  570 */     removeDirectionBranch();
/*  571 */     if (h == 0 && k == 0 && l == 0) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  576 */     this.directionBranch = new BranchGroup();
/*  577 */     this; this.directionBranch.setCapability(17);
/*  578 */     int origin = this.gridNum / 2;
/*  579 */     Vector3d v0 = new Vector3d(origin, origin, origin);
/*  580 */     v0 = shiftToCenter(v0, this.gridNum);
/*  581 */     v0 = this.lattice.coordinateConvert(v0);
/*  582 */     v0.scale(Logic.scale);
/*      */     
/*  584 */     double length = Math.sqrt((h * h + k * k + l * l));
/*  585 */     double hUnit = h / length;
/*  586 */     double kUnit = k / length;
/*  587 */     double lUnit = l / length;
/*  588 */     Vector3d v1 = new Vector3d(hUnit, kUnit, lUnit);
/*  589 */     v1.scale(((this.gridNum + 1) / 2) + 0.5D);
/*  590 */     v1.add((Tuple3d)new Vector3d(origin, origin, origin));
/*  591 */     v1 = shiftToCenter(v1, this.gridNum);
/*  592 */     v1 = this.lattice.coordinateConvert(v1);
/*  593 */     v1.scale(Logic.scale);
/*      */     
/*  595 */     Vector3d v2 = new Vector3d(v1);
/*  596 */     v2.sub((Tuple3d)v0);
/*  597 */     v2.scale((v2.length() - 0.05D) / v2.length());
/*      */     
/*  599 */     Vector3d v3 = new Vector3d(v0);
/*  600 */     v3.add((Tuple3d)v2);
/*      */ 
/*      */     
/*  603 */     Transform3D trans = getAxisTransform(v0, v3);
/*  604 */     TransformGroup t = new TransformGroup(trans);
/*  605 */     t.addChild((Node)new GridColumn(this.gridWidth - 0.001F, (float)v2.length(), Color.orange));
/*  606 */     this.directionBranch.addChild((Node)t);
/*      */     
/*  608 */     Cone cone = new Cone(0.015F, 0.05F);
/*  609 */     Appearance app = new Appearance();
/*  610 */     Material m = new Material();
/*  611 */     m.setAmbientColor(new Color3f(Color.orange));
/*  612 */     m.setDiffuseColor(new Color3f(Color.orange));
/*  613 */     m.setSpecularColor(1.0F, 1.0F, 1.0F);
/*  614 */     m.setShininess(64.0F);
/*  615 */     m.setEmissiveColor(new Color3f(0.0F, 0.0F, 0.0F));
/*  616 */     app.setMaterial(m);
/*  617 */     app.setColoringAttributes(new ColoringAttributes(new Color3f(Color.orange), 3));
/*  618 */     cone.setAppearance(app);
/*      */     
/*  620 */     trans = getAxisTransform(v3, v1);
/*  621 */     t = new TransformGroup(trans);
/*  622 */     t.addChild((Node)cone);
/*  623 */     this.directionBranch.addChild((Node)t);
/*      */ 
/*      */     
/*  626 */     Text2D text = new Text2D(String.valueOf(String.valueOf((new StringBuffer("[")).append(h).append(k).append(l).append("]"))), new Color3f(Color.orange), "Helvetica", 18, 0);
/*  627 */     PolygonAttributes pa = new PolygonAttributes();
/*  628 */     pa.setCullFace(0);
/*  629 */     text.getAppearance().setPolygonAttributes(pa);
/*      */     
/*  631 */     OrientedShape3D os = new OrientedShape3D(text.getGeometry(), text.getAppearance(), 1, new Point3f(0.0F, 0.0F, 0.0F));
/*  632 */     trans = new Transform3D();
/*  633 */     trans.setTranslation(v1);
/*  634 */     t = new TransformGroup(trans);
/*  635 */     t.addChild((Node)os);
/*  636 */     this.directionBranch.addChild((Node)t);
/*      */ 
/*      */     
/*  639 */     this.directionBranch.compile();
/*  640 */     addChild((Node)this.directionBranch);
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeDirectionBranch() {
/*  645 */     if (this.directionBranch != null) {
/*      */       
/*  647 */       removeChild((Node)this.directionBranch);
/*  648 */       this.directionBranch.detach();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void addLatticePointBranch() {
/*  654 */     removeLatticePointBranch();
/*  655 */     this.latticePointBranch = new BranchGroup();
/*      */     
/*  657 */     this; this.latticePointBranch.setCapability(17);
/*      */     
/*  659 */     for (int z = 0; z <= this.gridNum; z++) {
/*      */       
/*  661 */       for (int y = 0; y <= this.gridNum; y++) {
/*      */         
/*  663 */         for (int x = 0; x <= this.gridNum; x++) {
/*      */           
/*  665 */           Vector3d[] latticePoints = this.lattice.getLatticePoints();
/*  666 */           for (int i = 0; i < latticePoints.length; i++) {
/*      */             
/*  668 */             Vector3d p = new Vector3d(x, y, z);
/*  669 */             p.add((Tuple3d)latticePoints[i]);
/*      */             
/*  671 */             if (isInRange(p, this.gridNum)) {
/*      */               
/*  673 */               p = shiftToCenter(p, this.gridNum);
/*  674 */               p = this.lattice.coordinateConvert(p);
/*  675 */               p.scale(Logic.scale);
/*      */               
/*  677 */               Transform3D trans = new Transform3D();
/*  678 */               trans.setTranslation(p);
/*  679 */               TransformGroup t = new TransformGroup(trans);
/*  680 */               t.addChild((Node)new Atom(new AtomInfo(this.latticePointSize, this.latticePointColor)));
/*  681 */               this.latticePointBranch.addChild((Node)t);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*  687 */     this.latticePointBranch.compile();
/*  688 */     addChild((Node)this.latticePointBranch);
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeLatticePointBranch() {
/*  693 */     if (this.latticePointBranch != null) {
/*      */       
/*  695 */       removeChild((Node)this.latticePointBranch);
/*  696 */       this.latticePointBranch.detach();
/*      */       
/*      */       return;
/*      */     } 
/*  700 */     this.latticePointBranch = new BranchGroup();
/*  701 */     this; this.latticePointBranch.setCapability(17);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void addSingleCellBranch() {
/*  707 */     removeSingleCellBranch();
/*  708 */     this.singleCellBranch = new BranchGroup();
/*  709 */     this; this.singleCellBranch.setCapability(17);
/*  710 */     this; this.singleCellBranch.setCapability(11);
/*      */     
/*  712 */     int origin = this.gridNum / 2;
/*  713 */     Vector3d v0 = new Vector3d(origin, origin, origin);
/*  714 */     v0 = shiftToCenter(v0, this.gridNum);
/*  715 */     v0 = this.lattice.coordinateConvert(v0);
/*  716 */     v0.scale(Logic.scale);
/*      */ 
/*      */     
/*  719 */     Text2D text = new Text2D("O", new Color3f(Color.pink), "Helvetica", 18, 1);
/*  720 */     PolygonAttributes pa = new PolygonAttributes();
/*  721 */     pa.setCullFace(0);
/*  722 */     text.getAppearance().setPolygonAttributes(pa);
/*      */     
/*  724 */     OrientedShape3D os = new OrientedShape3D(text.getGeometry(), text.getAppearance(), 1, new Point3f(0.0F, 0.0F, 0.0F));
/*  725 */     Transform3D trans = new Transform3D();
/*  726 */     trans.setTranslation(v0);
/*  727 */     TransformGroup t = new TransformGroup(trans);
/*  728 */     t.addChild((Node)os);
/*  729 */     this.singleCellBranch.addChild((Node)t);
/*      */ 
/*      */     
/*  732 */     Vector3d v1 = new Vector3d((origin + 1), origin, origin);
/*  733 */     v1 = shiftToCenter(v1, this.gridNum);
/*  734 */     v1 = this.lattice.coordinateConvert(v1);
/*  735 */     v1.scale(Logic.scale);
/*      */ 
/*      */     
/*  738 */     Text2D text2D1 = new Text2D("a", new Color3f(Color.pink), "Helvetica", 18, 1);
/*  739 */     PolygonAttributes polygonAttributes1 = new PolygonAttributes();
/*  740 */     polygonAttributes1.setCullFace(0);
/*  741 */     text2D1.getAppearance().setPolygonAttributes(polygonAttributes1);
/*      */     
/*  743 */     OrientedShape3D orientedShape3D1 = new OrientedShape3D(text2D1.getGeometry(), text2D1.getAppearance(), 1, new Point3f(0.0F, 0.0F, 0.0F));
/*  744 */     Transform3D transform3D1 = new Transform3D();
/*  745 */     transform3D1.setTranslation(v1);
/*  746 */     TransformGroup transformGroup1 = new TransformGroup(transform3D1);
/*  747 */     transformGroup1.addChild((Node)orientedShape3D1);
/*  748 */     this.singleCellBranch.addChild((Node)transformGroup1);
/*      */ 
/*      */     
/*  751 */     Vector3d v2 = new Vector3d(origin, (origin + 1), origin);
/*  752 */     v2 = shiftToCenter(v2, this.gridNum);
/*  753 */     v2 = this.lattice.coordinateConvert(v2);
/*  754 */     v2.scale(Logic.scale);
/*      */ 
/*      */     
/*  757 */     Text2D text2D2 = new Text2D("b", new Color3f(Color.pink), "Helvetica", 18, 1);
/*  758 */     PolygonAttributes polygonAttributes2 = new PolygonAttributes();
/*  759 */     polygonAttributes2.setCullFace(0);
/*  760 */     text2D2.getAppearance().setPolygonAttributes(polygonAttributes2);
/*      */     
/*  762 */     OrientedShape3D orientedShape3D2 = new OrientedShape3D(text2D2.getGeometry(), text2D2.getAppearance(), 1, new Point3f(0.0F, 0.0F, 0.0F));
/*  763 */     Transform3D transform3D2 = new Transform3D();
/*  764 */     transform3D2.setTranslation(v2);
/*  765 */     TransformGroup transformGroup2 = new TransformGroup(transform3D2);
/*  766 */     transformGroup2.addChild((Node)orientedShape3D2);
/*  767 */     this.singleCellBranch.addChild((Node)transformGroup2);
/*      */ 
/*      */     
/*  770 */     Vector3d v3 = new Vector3d(origin, origin, (origin + 1));
/*  771 */     v3 = shiftToCenter(v3, this.gridNum);
/*  772 */     v3 = this.lattice.coordinateConvert(v3);
/*  773 */     v3.scale(Logic.scale);
/*      */ 
/*      */     
/*  776 */     Text2D text2D3 = new Text2D("c", new Color3f(Color.pink), "Helvetica", 18, 1);
/*  777 */     PolygonAttributes polygonAttributes3 = new PolygonAttributes();
/*  778 */     polygonAttributes3.setCullFace(0);
/*  779 */     text2D3.getAppearance().setPolygonAttributes(polygonAttributes3);
/*      */     
/*  781 */     OrientedShape3D orientedShape3D3 = new OrientedShape3D(text2D3.getGeometry(), text2D3.getAppearance(), 1, new Point3f(0.0F, 0.0F, 0.0F));
/*  782 */     Transform3D transform3D3 = new Transform3D();
/*  783 */     transform3D3.setTranslation(v3);
/*  784 */     TransformGroup transformGroup3 = new TransformGroup(transform3D3);
/*  785 */     transformGroup3.addChild((Node)orientedShape3D3);
/*  786 */     this.singleCellBranch.addChild((Node)transformGroup3);
/*      */ 
/*      */     
/*  789 */     Vector3d v4 = new Vector3d((origin + 1), (origin + 1), origin);
/*  790 */     v4 = shiftToCenter(v4, this.gridNum);
/*  791 */     v4 = this.lattice.coordinateConvert(v4);
/*  792 */     v4.scale(Logic.scale);
/*      */     
/*  794 */     Vector3d v5 = new Vector3d((origin + 1), origin, (origin + 1));
/*  795 */     v5 = shiftToCenter(v5, this.gridNum);
/*  796 */     v5 = this.lattice.coordinateConvert(v5);
/*  797 */     v5.scale(Logic.scale);
/*      */     
/*  799 */     Vector3d v6 = new Vector3d(origin, (origin + 1), (origin + 1));
/*  800 */     v6 = shiftToCenter(v6, this.gridNum);
/*  801 */     v6 = this.lattice.coordinateConvert(v6);
/*  802 */     v6.scale(Logic.scale);
/*      */     
/*  804 */     Vector3d v7 = new Vector3d((origin + 1), (origin + 1), (origin + 1));
/*  805 */     v7 = shiftToCenter(v7, this.gridNum);
/*  806 */     v7 = this.lattice.coordinateConvert(v7);
/*  807 */     v7.scale(Logic.scale);
/*      */     
/*  809 */     Transform3D transform3D4 = getAxisTransform(v0, v1);
/*  810 */     Vector3d v = new Vector3d(v1);
/*  811 */     v.sub((Tuple3d)v0);
/*  812 */     GridColumn g = new GridColumn(this.singleCellGridWidth, (float)v.length(), Color.pink);
/*  813 */     TransformGroup transformGroup4 = new TransformGroup(transform3D4);
/*  814 */     transformGroup4.addChild((Node)g);
/*  815 */     this.singleCellBranch.addChild((Node)transformGroup4);
/*      */     
/*  817 */     transform3D4 = getAxisTransform(v0, v2);
/*  818 */     v = new Vector3d(v2);
/*  819 */     v.sub((Tuple3d)v0);
/*  820 */     g = new GridColumn(this.singleCellGridWidth, (float)v.length(), Color.pink);
/*  821 */     transformGroup4 = new TransformGroup(transform3D4);
/*  822 */     transformGroup4.addChild((Node)g);
/*  823 */     this.singleCellBranch.addChild((Node)transformGroup4);
/*      */     
/*  825 */     transform3D4 = getAxisTransform(v0, v3);
/*  826 */     v = new Vector3d(v3);
/*  827 */     v.sub((Tuple3d)v0);
/*  828 */     g = new GridColumn(this.singleCellGridWidth, (float)v.length(), Color.pink);
/*  829 */     transformGroup4 = new TransformGroup(transform3D4);
/*  830 */     transformGroup4.addChild((Node)g);
/*  831 */     this.singleCellBranch.addChild((Node)transformGroup4);
/*      */     
/*  833 */     transform3D4 = getAxisTransform(v7, v4);
/*  834 */     v = new Vector3d(v4);
/*  835 */     v.sub((Tuple3d)v7);
/*  836 */     g = new GridColumn(this.singleCellGridWidth, (float)v.length(), Color.gray);
/*  837 */     transformGroup4 = new TransformGroup(transform3D4);
/*  838 */     transformGroup4.addChild((Node)g);
/*  839 */     this.singleCellBranch.addChild((Node)transformGroup4);
/*      */     
/*  841 */     transform3D4 = getAxisTransform(v7, v5);
/*  842 */     v = new Vector3d(v5);
/*  843 */     v.sub((Tuple3d)v7);
/*  844 */     g = new GridColumn(this.singleCellGridWidth, (float)v.length(), Color.gray);
/*  845 */     transformGroup4 = new TransformGroup(transform3D4);
/*  846 */     transformGroup4.addChild((Node)g);
/*  847 */     this.singleCellBranch.addChild((Node)transformGroup4);
/*      */     
/*  849 */     transform3D4 = getAxisTransform(v7, v6);
/*  850 */     v = new Vector3d(v6);
/*  851 */     v.sub((Tuple3d)v7);
/*  852 */     g = new GridColumn(this.singleCellGridWidth, (float)v.length(), Color.gray);
/*  853 */     transformGroup4 = new TransformGroup(transform3D4);
/*  854 */     transformGroup4.addChild((Node)g);
/*  855 */     this.singleCellBranch.addChild((Node)transformGroup4);
/*      */     
/*  857 */     transform3D4 = getAxisTransform(v1, v4);
/*  858 */     v = new Vector3d(v4);
/*  859 */     v.sub((Tuple3d)v1);
/*  860 */     g = new GridColumn(this.singleCellGridWidth, (float)v.length(), Color.gray);
/*  861 */     transformGroup4 = new TransformGroup(transform3D4);
/*  862 */     transformGroup4.addChild((Node)g);
/*  863 */     this.singleCellBranch.addChild((Node)transformGroup4);
/*      */     
/*  865 */     transform3D4 = getAxisTransform(v1, v5);
/*  866 */     v = new Vector3d(v5);
/*  867 */     v.sub((Tuple3d)v1);
/*  868 */     g = new GridColumn(this.singleCellGridWidth, (float)v.length(), Color.gray);
/*  869 */     transformGroup4 = new TransformGroup(transform3D4);
/*  870 */     transformGroup4.addChild((Node)g);
/*  871 */     this.singleCellBranch.addChild((Node)transformGroup4);
/*      */     
/*  873 */     transform3D4 = getAxisTransform(v5, v3);
/*  874 */     v = new Vector3d(v3);
/*  875 */     v.sub((Tuple3d)v5);
/*  876 */     g = new GridColumn(this.singleCellGridWidth, (float)v.length(), Color.gray);
/*  877 */     transformGroup4 = new TransformGroup(transform3D4);
/*  878 */     transformGroup4.addChild((Node)g);
/*  879 */     this.singleCellBranch.addChild((Node)transformGroup4);
/*      */     
/*  881 */     transform3D4 = getAxisTransform(v2, v4);
/*  882 */     v = new Vector3d(v4);
/*  883 */     v.sub((Tuple3d)v2);
/*  884 */     g = new GridColumn(this.singleCellGridWidth, (float)v.length(), Color.gray);
/*  885 */     transformGroup4 = new TransformGroup(transform3D4);
/*  886 */     transformGroup4.addChild((Node)g);
/*  887 */     this.singleCellBranch.addChild((Node)transformGroup4);
/*      */     
/*  889 */     transform3D4 = getAxisTransform(v2, v6);
/*  890 */     v = new Vector3d(v6);
/*  891 */     v.sub((Tuple3d)v2);
/*  892 */     g = new GridColumn(this.singleCellGridWidth, (float)v.length(), Color.gray);
/*  893 */     transformGroup4 = new TransformGroup(transform3D4);
/*  894 */     transformGroup4.addChild((Node)g);
/*  895 */     this.singleCellBranch.addChild((Node)transformGroup4);
/*      */     
/*  897 */     transform3D4 = getAxisTransform(v3, v6);
/*  898 */     v = new Vector3d(v6);
/*  899 */     v.sub((Tuple3d)v3);
/*  900 */     g = new GridColumn(this.singleCellGridWidth, (float)v.length(), Color.gray);
/*  901 */     transformGroup4 = new TransformGroup(transform3D4);
/*  902 */     transformGroup4.addChild((Node)g);
/*  903 */     this.singleCellBranch.addChild((Node)transformGroup4);
/*      */     
/*  905 */     this.singleCellBranch.compile();
/*  906 */     addChild((Node)this.singleCellBranch);
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeSingleCellBranch() {
/*  911 */     if (this.singleCellBranch != null) {
/*      */       
/*  913 */       removeChild((Node)this.singleCellBranch);
/*  914 */       this.singleCellBranch.detach();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void addGridBranch() {
/*  920 */     removeGridBranch();
/*  921 */     this.gridBranch = new BranchGroup();
/*  922 */     this; this.gridBranch.setCapability(17);
/*      */     
/*  924 */     for (int i = 0; i <= this.gridNum; i++) {
/*      */       
/*  926 */       for (int x = 0; x <= this.gridNum; x++) {
/*      */         
/*  928 */         Vector3d v1 = new Vector3d(x, i, 0.0D);
/*  929 */         Vector3d v2 = new Vector3d(x, i, this.gridNum);
/*      */         
/*  931 */         v1 = shiftToCenter(v1, this.gridNum);
/*  932 */         v2 = shiftToCenter(v2, this.gridNum);
/*      */         
/*  934 */         v1 = this.lattice.coordinateConvert(v1);
/*  935 */         v2 = this.lattice.coordinateConvert(v2);
/*      */         
/*  937 */         v1.scale(Logic.scale);
/*  938 */         v2.scale(Logic.scale);
/*      */         
/*  940 */         Transform3D trans = getAxisTransform(v1, v2);
/*  941 */         TransformGroup t = new TransformGroup(trans);
/*  942 */         v2.sub((Tuple3d)v1);
/*  943 */         t.addChild((Node)new GridColumn(this.gridWidth, (float)v2.length(), Color.gray));
/*      */         
/*  945 */         this.gridBranch.addChild((Node)t);
/*      */       } 
/*      */     } 
/*      */     
/*  949 */     for (int z = 0; z <= this.gridNum; z++) {
/*      */       
/*  951 */       for (int x = 0; x <= this.gridNum; x++) {
/*      */         
/*  953 */         Vector3d v1 = new Vector3d(x, 0.0D, z);
/*  954 */         Vector3d v2 = new Vector3d(x, this.gridNum, z);
/*      */         
/*  956 */         v1 = shiftToCenter(v1, this.gridNum);
/*  957 */         v2 = shiftToCenter(v2, this.gridNum);
/*      */         
/*  959 */         v1 = this.lattice.coordinateConvert(v1);
/*  960 */         v2 = this.lattice.coordinateConvert(v2);
/*      */         
/*  962 */         v1.scale(Logic.scale);
/*  963 */         v2.scale(Logic.scale);
/*      */         
/*  965 */         Transform3D trans = getAxisTransform(v1, v2);
/*  966 */         TransformGroup t = new TransformGroup(trans);
/*  967 */         v2.sub((Tuple3d)v1);
/*  968 */         t.addChild((Node)new GridColumn(this.gridWidth, (float)v2.length(), Color.gray));
/*      */         
/*  970 */         this.gridBranch.addChild((Node)t);
/*      */       } 
/*      */     } 
/*  973 */     for (int y = 0; y <= this.gridNum; y++) {
/*      */       
/*  975 */       for (int j = 0; j <= this.gridNum; j++) {
/*      */         
/*  977 */         Vector3d v1 = new Vector3d(0.0D, y, j);
/*  978 */         Vector3d v2 = new Vector3d(this.gridNum, y, j);
/*      */         
/*  980 */         v1 = shiftToCenter(v1, this.gridNum);
/*  981 */         v2 = shiftToCenter(v2, this.gridNum);
/*      */         
/*  983 */         v1 = this.lattice.coordinateConvert(v1);
/*  984 */         v2 = this.lattice.coordinateConvert(v2);
/*      */         
/*  986 */         v1.scale(Logic.scale);
/*  987 */         v2.scale(Logic.scale);
/*      */         
/*  989 */         Transform3D trans = getAxisTransform(v1, v2);
/*  990 */         TransformGroup t = new TransformGroup(trans);
/*  991 */         v2.sub((Tuple3d)v1);
/*  992 */         t.addChild((Node)new GridColumn(this.gridWidth, (float)v2.length(), Color.gray));
/*      */         
/*  994 */         this.gridBranch.addChild((Node)t);
/*      */       } 
/*      */     } 
/*  997 */     this.gridBranch.compile();
/*  998 */     addChild((Node)this.gridBranch);
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeGridBranch() {
/* 1003 */     if (this.gridBranch != null) {
/*      */       
/* 1005 */       removeChild((Node)this.gridBranch);
/* 1006 */       this.gridBranch.detach();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void removeAtomsBranch() {
/* 1012 */     if (this.atomBranch != null) {
/*      */       
/* 1014 */       removeChild((Node)this.atomBranch);
/* 1015 */       this.atomBranch.detach();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void addAtomsBranch() {
/* 1021 */     removeAtomsBranch();
/* 1022 */     this.atomBranch = new BranchGroup();
/* 1023 */     this; this.atomBranch.setCapability(17);
/*      */     
/* 1025 */     for (int z = 0; z <= this.gridNum; z++) {
/*      */       
/* 1027 */       for (int y = 0; y <= this.gridNum; y++) {
/*      */         
/* 1029 */         for (int x = 0; x <= this.gridNum; x++) {
/*      */           
/* 1031 */           Vector3d[] latticePoints = this.lattice.getLatticePoints();
/* 1032 */           for (int i = 0; i < latticePoints.length; i++) {
/*      */             
/* 1034 */             Vector3d p = new Vector3d(x, y, z);
/* 1035 */             p.add((Tuple3d)latticePoints[i]);
/* 1036 */             for (int j = 0; j < this.attachedAtomInfos.length; j++) {
/*      */               
/* 1038 */               Vector3d pp = new Vector3d(p);
/* 1039 */               pp.add((Tuple3d)this.atomShifts[j]);
/* 1040 */               if (isInRange(pp, this.gridNum)) {
/*      */                 
/* 1042 */                 TransformGroup t = new TransformGroup();
/* 1043 */                 Transform3D trans = new Transform3D();
/* 1044 */                 Vector3d v = shiftToCenter(pp, this.gridNum);
/* 1045 */                 Vector3d real = this.lattice.coordinateConvert(v);
/* 1046 */                 real.scale(Logic.scale);
/* 1047 */                 trans.setTranslation(real);
/* 1048 */                 t.setTransform(trans);
/* 1049 */                 t.addChild((Node)new Atom(this.attachedAtomInfos[j]));
/* 1050 */                 this.atomBranch.addChild((Node)t);
/*      */               } 
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/* 1057 */     this.atomBranch.compile();
/* 1058 */     addChild((Node)this.atomBranch);
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean isInRange(Vector3d v, int grid) {
/* 1063 */     if (Logic.doubleLessEqual(((Tuple3d)v).x, grid) && Logic.doubleLessEqual(((Tuple3d)v).y, grid) && Logic.doubleLessEqual(((Tuple3d)v).z, grid) && Logic.doubleGreatEqual(((Tuple3d)v).x, 0.0D) && Logic.doubleGreatEqual(((Tuple3d)v).y, 0.0D) && Logic.doubleGreatEqual(((Tuple3d)v).z, 0.0D))
/*      */     {
/* 1065 */       return true;
/*      */     }
/* 1067 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   private Vector3d shiftToCenter(Vector3d v, int grid) {
/* 1072 */     double shift = grid * 0.5D;
/* 1073 */     return new Vector3d(((Tuple3d)v).x - shift, ((Tuple3d)v).y - shift, ((Tuple3d)v).z - shift);
/*      */   }
/*      */ 
/*      */   
/*      */   private Transform3D getAxisTransform(Vector3d v1, Vector3d v2) {
/* 1078 */     Vector3d v3 = new Vector3d(v2);
/* 1079 */     v3.sub((Tuple3d)v1);
/* 1080 */     Vector3d y0 = new Vector3d(0.0D, 2.0D, 0.0D);
/* 1081 */     double angle = v3.angle(y0);
/* 1082 */     Vector3d rot = new Vector3d();
/* 1083 */     rot.cross(y0, v3);
/* 1084 */     Transform3D trans = new Transform3D();
/* 1085 */     trans.set(new AxisAngle4d(rot, angle));
/* 1086 */     trans.setTranslation(new Vector3d((((Tuple3d)v1).x + ((Tuple3d)v2).x) / 2, (((Tuple3d)v1).y + ((Tuple3d)v2).y) / 2, (((Tuple3d)v1).z + ((Tuple3d)v2).z) / 2));
/* 1087 */     return trans;
/*      */   }
/*      */ 
/*      */   
/*      */   private Appearance createPlaneAppearance() {
/* 1092 */     Appearance app = new Appearance();
/* 1093 */     app.setTransparencyAttributes(new TransparencyAttributes(2, Logic.planeAlpha));
/* 1094 */     PolygonAttributes pa = new PolygonAttributes(2, 0, 0.0F);
/* 1095 */     pa.setBackFaceNormalFlip(false);
/* 1096 */     app.setPolygonAttributes(pa);
/* 1097 */     ColoringAttributes ca = new ColoringAttributes(new Color3f(Color.lightGray), 3);
/* 1098 */     app.setColoringAttributes(ca);
/* 1099 */     Material m = new Material();
/* 1100 */     m.setAmbientColor(new Color3f(Color.lightGray));
/* 1101 */     m.setDiffuseColor(new Color3f(Color.lightGray));
/* 1102 */     m.setSpecularColor(1.0F, 1.0F, 1.0F);
/* 1103 */     m.setShininess(64.0F);
/* 1104 */     m.setEmissiveColor(new Color3f(Color.lightGray));
/* 1105 */     app.setMaterial(m);
/* 1106 */     return app;
/*      */   }
/*      */ }


/* Location:              C:\Users\Evgeniy\IdeaProjects\modern-lab-comp-applets\src\Lab_1\Cell & Properties\\\unitcell21.jar!\Crystal.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */