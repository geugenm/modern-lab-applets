/*     */ import com.sun.j3d.utils.universe.SimpleUniverse;
/*     */ import java.awt.datatransfer.DataFlavor;
/*     */ import java.awt.event.MouseEvent;
/*     */ import javax.media.j3d.BranchGroup;
/*     */ import javax.media.j3d.Node;
/*     */ import javax.media.j3d.Transform3D;
/*     */ 
/*     */ public class DemoUniverse extends Canvas3D {
/*     */   private SimpleUniverse su;
/*     */   private TransformGroup root;
/*     */   private BranchGroup objRoot;
/*     */   private Background background;
/*     */   private BranchGroup base;
/*     */   
/*     */   private class UpdateThread extends Thread {
/*     */     boolean stop;
/*     */     
/*  18 */     private UpdateThread(DemoUniverse this$0) { DemoUniverse.this = DemoUniverse.this;
/*     */       
/*  20 */       this.stop = false; } private final DemoUniverse this$0; UpdateThread(DemoUniverse.$1 x$1) {
/*     */       this();
/*     */     } public void run() {
/*  23 */       while (!this.stop) {
/*     */         
/*  25 */         Graphics g = DemoUniverse.this.getGraphics();
/*  26 */         if (g != null) {
/*     */           
/*  28 */           DemoUniverse.this.paint(null);
/*     */           
/*     */           try {
/*  31 */             Thread.sleep(500L);
/*     */           }
/*  33 */           catch (InterruptedException interruptedException) {}
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   class ImageSelection
/*     */     implements Transferable
/*     */   {
/*     */     private Image image;
/*     */     
/*     */     public ImageSelection(DemoUniverse this$0, Image image) {
/*  46 */       this.image = image;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public DataFlavor[] getTransferDataFlavors() {
/*  52 */       return new DataFlavor[] { DataFlavor.imageFlavor };
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isDataFlavorSupported(DataFlavor flavor) {
/*  60 */       return DataFlavor.imageFlavor.equals(flavor);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     public Object getTransferData(DataFlavor flavor) throws IOException, UnsupportedFlavorException {
/*  66 */       if (!DataFlavor.imageFlavor.equals(flavor))
/*     */       {
/*  68 */         throw new UnsupportedFlavorException(flavor);
/*     */       }
/*  70 */       return this.image;
/*     */     }
/*     */   }
/*     */   
/*     */   boolean capture = false;
/*     */   
/*     */   public void postSwap() {
/*  77 */     if (this.capture) {
/*     */       
/*  79 */       this.capture = false;
/*  80 */       Raster ras = new Raster(new Point3f(-1.0F, -1.0F, -1.0F), 1, 0, 0, 400, 400, new ImageComponent2D(1, new BufferedImage(400, 400, 1)), null);
/*     */       
/*  82 */       GraphicsContext3D gc3 = getGraphicsContext3D();
/*  83 */       gc3.readRaster(ras);
/*  84 */       BufferedImage img = ras.getImage().getImage();
/*     */       
/*  86 */       ImageSelection imgSel = new ImageSelection(this, img);
/*  87 */       Toolkit.getDefaultToolkit().getSystemClipboard().setContents(imgSel, null);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public DemoUniverse() {
/*  93 */     super(SimpleUniverse.getPreferredConfiguration());
/*  94 */     this.su = new SimpleUniverse(this);
/*  95 */     this.su.getViewer().getView().setProjectionPolicy(0);
/*  96 */     Transform3D viewer = new Transform3D();
/*     */ 
/*     */     
/*  99 */     this.su.getViewingPlatform().setNominalViewingTransform();
/*     */     
/* 101 */     this.su.addBranchGraph(createBasicBranch());
/*     */     
/* 103 */     Mouse m = new Mouse(this);
/* 104 */     addMouseListener(m);
/* 105 */     addMouseMotionListener(m);
/* 106 */     UpdateThread ut = new UpdateThread(null);
/* 107 */     ut.start();
/*     */   }
/*     */ 
/*     */   
/*     */   private BranchGroup createBasicBranch() {
/* 112 */     BranchGroup bg = new BranchGroup();
/* 113 */     bg.setCapability(13);
/* 114 */     bg.setCapability(14);
/* 115 */     this.base = bg;
/*     */     
/* 117 */     DirectionalLight dl = new DirectionalLight();
/* 118 */     dl.setInfluencingBounds((Bounds)new BoundingSphere());
/* 119 */     bg.addChild((Node)dl);
/*     */     
/* 121 */     this.background = new Background(0.0F, 0.0F, 0.0F);
/*     */     
/* 123 */     this; this.background.setCapability(12);
/* 124 */     this; this.background.setCapability(13);
/* 125 */     this; this.background.setCapability(16);
/* 126 */     this; this.background.setCapability(17);
/* 127 */     this; this.background.setCapability(18);
/* 128 */     this; this.background.setCapability(19);
/* 129 */     this; this.background.setCapability(14);
/* 130 */     this; this.background.setCapability(20);
/* 131 */     this; this.background.setCapability(21);
/* 132 */     this; this.background.setCapability(15);
/*     */     
/* 134 */     this.background.setApplicationBounds((Bounds)new BoundingSphere(new Point3d(), 100.0D));
/* 135 */     bg.addChild((Node)this.background);
/*     */     
/* 137 */     this.root = new TransformGroup();
/*     */     
/* 139 */     this; this.root.setCapability(17);
/* 140 */     this; this.root.setCapability(18);
/*     */     
/* 142 */     this; this.root.setCapability(12);
/* 143 */     this; this.root.setCapability(13);
/* 144 */     this; this.root.setCapability(14);
/*     */     
/* 146 */     bg.addChild((Node)this.root);
/* 147 */     this.objRoot = new BranchGroup();
/* 148 */     this; this.objRoot.setCapability(14);
/* 149 */     this; this.objRoot.setCapability(12);
/* 150 */     this; this.objRoot.setCapability(13);
/* 151 */     this; this.objRoot.setCapability(17);
/* 152 */     this.root.addChild((Node)this.objRoot);
/* 153 */     return bg;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setRootObject(BranchGroup objRoot) {
/* 158 */     if (objRoot != null) {
/*     */       
/* 160 */       objRoot.setCapability(17);
/* 161 */       objRoot.setCapability(14);
/* 162 */       if (this.objRoot == null) {
/*     */         
/* 164 */         this.root.addChild((Node)objRoot);
/*     */       }
/*     */       else {
/*     */         
/* 168 */         this.root.removeChild((Node)this.objRoot);
/* 169 */         this.objRoot.detach();
/* 170 */         this.root.addChild((Node)objRoot);
/*     */       } 
/* 172 */       this.objRoot = objRoot;
/*     */     }
/*     */     else {
/*     */       
/* 176 */       this.root.removeChild((Node)this.objRoot);
/* 177 */       objRoot.detach();
/* 178 */       objRoot = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public BranchGroup getRootObject() {
/* 184 */     return this.objRoot;
/*     */   }
/*     */ 
/*     */   
/*     */   public Transform3D getTransform3D() {
/* 189 */     Transform3D t = new Transform3D();
/* 190 */     this.root.getTransform(t);
/* 191 */     return t;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTransform3D(Transform3D t) {
/* 196 */     this.root.setTransform(t);
/*     */   }
/*     */ 
/*     */   
/*     */   public SimpleUniverse getUniverse() {
/* 201 */     return this.su;
/*     */   }
/*     */ 
/*     */   
/*     */   public Background getUniverseBackground() {
/* 206 */     return this.background;
/*     */   } class Mouse extends MouseAdapter implements MouseMotionListener { int preX; int preY; int preX2; int preY2; private final DemoUniverse this$0;
/*     */     Mouse(DemoUniverse this$0) {
/* 209 */       this.this$0 = this$0;
/*     */     }
/*     */ 
/*     */     
/*     */     public void mousePressed(MouseEvent e) {
/* 214 */       if (e.getModifiers() == 16) {
/*     */         
/* 216 */         this.preX = e.getX();
/* 217 */         this.preY = e.getY();
/*     */       } 
/* 219 */       if (e.getModifiers() == 8 || e.getModifiers() == 4) {
/*     */         
/* 221 */         this.preX2 = e.getX();
/* 222 */         this.preY2 = e.getY();
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void mouseDragged(MouseEvent e) {
/* 228 */       if (e.getModifiers() == 16) {
/*     */         
/* 230 */         int x = e.getX();
/* 231 */         int y = e.getY();
/* 232 */         Transform3D t = new Transform3D();
/* 233 */         this.this$0.root.getTransform(t);
/* 234 */         Transform3D trans = new Transform3D();
/* 235 */         t.invert();
/* 236 */         trans.rotY(Math.toRadians(-(x - this.preX)) / 2);
/* 237 */         t.mul(trans);
/* 238 */         trans.rotX(Math.toRadians(-(y - this.preY)) / 2);
/* 239 */         t.mul(trans);
/* 240 */         t.invert();
/* 241 */         this.this$0.root.setTransform(t);
/* 242 */         this.preX = x;
/* 243 */         this.preY = y;
/*     */       } 
/* 245 */       if (e.getModifiers() == 8 || e.getModifiers() == 4) {
/*     */         
/* 247 */         int x = e.getX();
/* 248 */         int y = e.getY();
/* 249 */         Transform3D t = new Transform3D();
/* 250 */         this.this$0.root.getTransform(t);
/* 251 */         Transform3D trans = new Transform3D();
/* 252 */         if (y - this.preY2 < 0) {
/*     */           
/* 254 */           trans.setScale(0.99D);
/*     */         }
/* 256 */         else if (this.preY2 - y < 0) {
/*     */           
/* 258 */           trans.setScale(1.0101010101010102D);
/*     */         } 
/* 260 */         t.mul(trans);
/* 261 */         this.this$0.root.setTransform(t);
/*     */       } 
/*     */     }
/*     */     
/*     */     public void mouseMoved(MouseEvent e) {} }
/*     */ 
/*     */ }


/* Location:              C:\Users\Evgeniy\IdeaProjects\modern-lab-comp-applets\src\Lab_1\Cell & Properties\\\unitcell21.jar!\DemoUniverse.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */