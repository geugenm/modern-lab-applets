/*    */ import com.sun.j3d.utils.geometry.Cylinder;
/*    */ import java.awt.Color;
/*    */ import javax.media.j3d.Appearance;
/*    */ import javax.media.j3d.ColoringAttributes;
/*    */ import javax.media.j3d.PolygonAttributes;
/*    */ import javax.vecmath.Color3f;
/*    */ 
/*    */ public class GridColumn extends Cylinder {
/*    */   public GridColumn(float radius, float height, Color color) {
/* 10 */     super(radius, height, 1, new Appearance());
/* 11 */     setAppearance(createAppearance(color));
/*    */   }
/*    */ 
/*    */   
/*    */   private Appearance createAppearance(Color c) {
/* 16 */     Appearance app = new Appearance();
/* 17 */     PolygonAttributes pa = new PolygonAttributes(2, 1, 0.0F);
/* 18 */     app.setPolygonAttributes(pa);
/* 19 */     ColoringAttributes ca = new ColoringAttributes(new Color3f(c), 3);
/* 20 */     app.setColoringAttributes(ca);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 28 */     return app;
/*    */   }
/*    */ }


/* Location:              C:\Users\Evgeniy\IdeaProjects\modern-lab-comp-applets\src\Lab_1\Cell & Properties\\\unitcell21.jar!\GridColumn.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */