/*    */ import java.awt.Font;
/*    */ import java.awt.Graphics;
/*    */ import javax.swing.JComponent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class null
/*    */   extends JComponent
/*    */ {
/*    */   null(ParameterPanel this$0) {}
/*    */   
/*    */   protected void paintComponent(Graphics g) {
/* 35 */     Font f = new Font("DialogInput", 0, 12);
/* 36 */     g.setFont(f);
/* 37 */     for (int i = 0; i < 3; i++) {
/*    */       
/* 39 */       g.drawString("A", 2, 16 + 25 * i);
/* 40 */       g.drawOval(3, 2 + 25 * i, 3, 3);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Evgeniy\IdeaProjects\modern-lab-comp-applets\src\Lab_1\Cell & Properties\\\unitcell21.jar!\ParameterPanel$1.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */