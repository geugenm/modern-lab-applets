/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseMotionListener;
/*     */ import javax.media.j3d.Transform3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Mouse
/*     */   extends MouseAdapter
/*     */   implements MouseMotionListener
/*     */ {
/*     */   int preX;
/*     */   int preY;
/*     */   int preX2;
/*     */   int preY2;
/*     */   private final DemoUniverse this$0;
/*     */   
/*     */   Mouse(DemoUniverse this$0) {
/* 209 */     this.this$0 = this$0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void mousePressed(MouseEvent e) {
/* 214 */     if (e.getModifiers() == 16) {
/*     */       
/* 216 */       this.preX = e.getX();
/* 217 */       this.preY = e.getY();
/*     */     } 
/* 219 */     if (e.getModifiers() == 8 || e.getModifiers() == 4) {
/*     */       
/* 221 */       this.preX2 = e.getX();
/* 222 */       this.preY2 = e.getY();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void mouseDragged(MouseEvent e) {
/* 228 */     if (e.getModifiers() == 16) {
/*     */       
/* 230 */       int x = e.getX();
/* 231 */       int y = e.getY();
/* 232 */       Transform3D t = new Transform3D();
/* 233 */       DemoUniverse.access$0(this.this$0).getTransform(t);
/* 234 */       Transform3D trans = new Transform3D();
/* 235 */       t.invert();
/* 236 */       trans.rotY(Math.toRadians(-(x - this.preX)) / 2);
/* 237 */       t.mul(trans);
/* 238 */       trans.rotX(Math.toRadians(-(y - this.preY)) / 2);
/* 239 */       t.mul(trans);
/* 240 */       t.invert();
/* 241 */       DemoUniverse.access$0(this.this$0).setTransform(t);
/* 242 */       this.preX = x;
/* 243 */       this.preY = y;
/*     */     } 
/* 245 */     if (e.getModifiers() == 8 || e.getModifiers() == 4) {
/*     */       
/* 247 */       int x = e.getX();
/* 248 */       int y = e.getY();
/* 249 */       Transform3D t = new Transform3D();
/* 250 */       DemoUniverse.access$0(this.this$0).getTransform(t);
/* 251 */       Transform3D trans = new Transform3D();
/* 252 */       if (y - this.preY2 < 0) {
/*     */         
/* 254 */         trans.setScale(0.99D);
/*     */       }
/* 256 */       else if (this.preY2 - y < 0) {
/*     */         
/* 258 */         trans.setScale(1.0101010101010102D);
/*     */       } 
/* 260 */       t.mul(trans);
/* 261 */       DemoUniverse.access$0(this.this$0).setTransform(t);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void mouseMoved(MouseEvent e) {}
/*     */ }


/* Location:              C:\Users\Evgeniy\IdeaProjects\modern-lab-comp-applets\src\Lab_1\Cell & Properties\\\unitcell21.jar!\DemoUniverse$Mouse.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */