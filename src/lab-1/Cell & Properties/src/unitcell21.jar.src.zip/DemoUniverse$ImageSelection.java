/*    */ import java.awt.Image;
/*    */ import java.awt.datatransfer.DataFlavor;
/*    */ import java.awt.datatransfer.Transferable;
/*    */ import java.awt.datatransfer.UnsupportedFlavorException;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ImageSelection
/*    */   implements Transferable
/*    */ {
/*    */   private Image image;
/*    */   
/*    */   public ImageSelection(DemoUniverse this$0, Image image) {
/* 46 */     this.image = image;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public DataFlavor[] getTransferDataFlavors() {
/* 52 */     return new DataFlavor[] { DataFlavor.imageFlavor };
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean isDataFlavorSupported(DataFlavor flavor) {
/* 60 */     return DataFlavor.imageFlavor.equals(flavor);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Object getTransferData(DataFlavor flavor) throws IOException, UnsupportedFlavorException {
/* 66 */     if (!DataFlavor.imageFlavor.equals(flavor))
/*    */     {
/* 68 */       throw new UnsupportedFlavorException(flavor);
/*    */     }
/* 70 */     return this.image;
/*    */   }
/*    */ }


/* Location:              C:\Users\Evgeniy\IdeaProjects\modern-lab-comp-applets\src\Lab_1\Cell & Properties\\\unitcell21.jar!\DemoUniverse$ImageSelection.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */