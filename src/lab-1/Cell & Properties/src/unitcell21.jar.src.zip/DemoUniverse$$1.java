interface $1 {}


/* Location:              C:\Users\Evgeniy\IdeaProjects\modern-lab-comp-applets\src\Lab_1\Cell & Properties\\\unitcell21.jar!\DemoUniverse$$1.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */