/*    */ import java.awt.Color;
/*    */ import javax.media.j3d.Appearance;
/*    */ import javax.media.j3d.Material;
/*    */ import javax.media.j3d.PolygonAttributes;
/*    */ import javax.vecmath.Color3f;
/*    */ 
/*    */ public class Atom extends Sphere {
/*    */   public Atom(AtomInfo atomInfo) {
/*  9 */     super((float)atomInfo.getRadius(), 1, new Appearance());
/* 10 */     setAppearance(createAppearance(atomInfo.getAtomColor()));
/*    */   }
/*    */ 
/*    */   
/*    */   private Appearance createAppearance(Color c) {
/* 15 */     Appearance app = new Appearance();
/* 16 */     PolygonAttributes pa = new PolygonAttributes(2, 1, 0.0F);
/* 17 */     app.setPolygonAttributes(pa);
/* 18 */     ColoringAttributes ca = new ColoringAttributes(new Color3f(c), 3);
/* 19 */     app.setColoringAttributes(ca);
/* 20 */     Material m = new Material();
/* 21 */     m.setAmbientColor(new Color3f(c));
/* 22 */     m.setDiffuseColor(new Color3f(c));
/* 23 */     m.setSpecularColor(1.0F, 1.0F, 1.0F);
/* 24 */     m.setShininess(64.0F);
/* 25 */     m.setEmissiveColor(new Color3f(0.0F, 0.0F, 0.0F));
/* 26 */     app.setMaterial(m);
/* 27 */     return app;
/*    */   }
/*    */ }


/* Location:              C:\Users\Evgeniy\IdeaProjects\modern-lab-comp-applets\src\Lab_1\Cell & Properties\\\unitcell21.jar!\Atom.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */