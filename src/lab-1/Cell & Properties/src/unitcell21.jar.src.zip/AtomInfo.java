/*    */ import java.awt.Color;
/*    */ 
/*    */ public class AtomInfo
/*    */ {
/*  5 */   private double radius = 0.01D;
/*  6 */   private Color atomColor = new Color(128, 128, 128);
/*    */ 
/*    */   
/*    */   public AtomInfo(double radius, Color color) {
/* 10 */     this.atomColor = color;
/* 11 */     this.radius = radius;
/*    */   }
/*    */ 
/*    */   
/*    */   public Color getAtomColor() {
/* 16 */     return this.atomColor;
/*    */   }
/*    */ 
/*    */   
/*    */   public double getRadius() {
/* 21 */     return this.radius;
/*    */   }
/*    */ }


/* Location:              C:\Users\Evgeniy\IdeaProjects\modern-lab-comp-applets\src\Lab_1\Cell & Properties\\\unitcell21.jar!\AtomInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.1.3
 */